// Global variables
let currentUser = null;
let currentTicket = null;
let tickets = [];
let selectedTickets = [];

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

function initializeApp() {
    seedTestUsers();
    // Check if user is logged in
    const user = getCurrentUser();
    if (user) {
        currentUser = user;
        setupPageBasedOnRole();
    }

    // Setup event listeners
    setupEventListeners();
    
    // Load initial data
    loadInitialData();
}

function setupEventListeners() {
    // Category selection on triage page
    const categoryCards = document.querySelectorAll('.category-card');
    categoryCards.forEach(card => {
        card.addEventListener('click', function() {
            const category = this.dataset.category;
            localStorage.setItem('selectedCategory', category);
            window.location.href = 'ticket-form.html';
        });
    });

    // Login form
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }

    // Ticket form
    const ticketForm = document.getElementById('ticketForm');
    if (ticketForm) {
        ticketForm.addEventListener('submit', handleTicketSubmission);
    }

    // Dashboard filters
    const statusFilter = document.getElementById('statusFilter');
    const categoryFilter = document.getElementById('categoryFilter');
    if (statusFilter) statusFilter.addEventListener('change', filterTickets);
    if (categoryFilter) categoryFilter.addEventListener('change', filterTickets);

    // Checkbox selection for bulk operations
    document.addEventListener('change', function(e) {
        if (e.target.type === 'checkbox' && e.target.name === 'ticketSelect') {
            handleTicketSelection(e.target);
        }
    });
}

function setupPageBasedOnRole() {
    const currentPage = window.location.pathname.split('/').pop();
    
    if (currentPage === 'dashboard.html') {
        setupDashboard();
    } else if (currentPage === 'ticket-form.html') {
        setupTicketForm();
    } else if (currentPage === 'ticket-detail.html') {
        setupTicketDetail();
    } else if (currentPage === 'pobj.html') {
        setupPOBJ();
    }
}

function setupDashboard() {
    if (!currentUser) return;
    // Atualizar nome do usuário no header
    const userNameEl = document.getElementById('welcomeUserName');
    if (userNameEl) userNameEl.textContent = currentUser.name;
    // Mostrar filtro de analista só para admin
    if (currentUser.role === 'admin') {
        document.querySelectorAll('.admin-only').forEach(el => el.style.display = 'block');
        preencherFiltroAnalista();
    }
    // Filtros de data já estão sempre visíveis para admin e analista (HTML)
    // Show/hide elements based on role
    const bulkUpdateBtn = document.getElementById('bulkUpdateBtn');
    if (currentUser.role === 'analyst' && bulkUpdateBtn) {
        bulkUpdateBtn.style.display = 'inline-block';
    }
    loadTickets();
}

function preencherFiltroAnalista() {
    const select = document.getElementById('analystFilter');
    if (!select) return;
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const analysts = users.filter(u => u.role === 'analyst');
    select.innerHTML = '<option value="">Todos</option>' + analysts.map(a => `<option value="${a.id}">${a.name} (${a.email})</option>`).join('');
}

// Mock de contas e gerentes para busca
const mockContas = [
    { id: '001', label: 'Conta 001 - XPTO' },
    { id: '002', label: 'Conta 002 - ABC' },
    { id: '003', label: 'Conta 003 - DEF' },
    { id: '004', label: 'Conta 004 - GHI' },
    { id: '005', label: 'Conta 005 - JKL' }
];
const mockGerentes = [
    { id: 'g1', name: 'Carlos Silva', email: 'carlos@empresa.com' },
    { id: 'g2', name: 'Fernanda Souza', email: 'fernanda@empresa.com' },
    { id: 'g3', name: 'Joana Lima', email: 'joana@empresa.com' },
    { id: 'g4', name: 'Paulo Mendes', email: 'henrique.bardella@gmail.com' }
];

function setupTicketForm() {
    const selectedCategory = localStorage.getItem('selectedCategory');
    if (!selectedCategory) {
        window.location.href = 'index.html';
        return;
    }
    document.getElementById('selectedCategory').textContent = getCategoryDisplayName(selectedCategory);
    loadCategoryFields(selectedCategory);
    const selectContas = document.getElementById('encContas');
    const contasView = document.getElementById('contasSelecionadasView');
    if (selectedCategory === 'encarteiramento') {
        if (document.getElementById('commonFields')) document.getElementById('commonFields').style.display = 'none';
        document.getElementById('encarteiramentoFields').style.display = 'block';
        preencherContasMock();
        preencherGerentesMock('encGerenteSolicitante');
        preencherGerentesMock('encGerenteCedente');
        preencherGerentesMock('encGerenteRegional');
        // Exibir contas selecionadas como tags
        if (selectContas && contasView) {
            function updateContasView() {
                const selected = Array.from(selectContas.selectedOptions).map(opt => `<span class='selected-tag'>${opt.text}</span>`).join(' ');
                contasView.innerHTML = selected || '<span class="text-muted">Nenhuma conta selecionada</span>';
            }
            selectContas.addEventListener('change', updateContasView);
            updateContasView();
        }
        // Lógica para mostrar/ocultar gerente regional
        const tipoSelect = document.getElementById('encTipoSolicitacao');
        const rowRegional = document.getElementById('rowGerenteRegional');
        function toggleGerenteRegional() {
            const val = tipoSelect.value;
            if (val === 'icex' || val === 'icvx') {
                rowRegional.style.display = 'flex';
                document.getElementById('encGerenteRegional').setAttribute('required', 'required');
            } else {
                rowRegional.style.display = 'none';
                document.getElementById('encGerenteRegional').removeAttribute('required');
            }
        }
        tipoSelect.addEventListener('change', toggleGerenteRegional);
        toggleGerenteRegional();
    } else {
        if (document.getElementById('commonFields')) document.getElementById('commonFields').style.display = 'block';
        const encFields = document.getElementById('encarteiramentoFields');
        if (encFields) encFields.style.display = 'none';
        if (contasView) contasView.innerHTML = '';
    }
}

function renderContasMultiDropdown() {
    const contasOptionsDiv = document.getElementById('contasOptions');
    const contasSelectedDiv = document.getElementById('contasSelected');
    const contasSearch = document.getElementById('contasSearch');
    const inputHidden = document.getElementById('contasSelecionadas');
    if (!contasOptionsDiv || !contasSelectedDiv || !contasSearch || !inputHidden) return;
    let selectedIds = [];
    function renderOptions(filter = '') {
        const filtered = mockContas.filter(c => c.label.toLowerCase().includes(filter.toLowerCase()));
        contasOptionsDiv.innerHTML = filtered.map(c => `
            <div class="dropdown-option${selectedIds.includes(c.id) ? ' selected' : ''}" data-id="${c.id}">${c.label}</div>
        `).join('');
    }
    function renderSelected() {
        contasSelectedDiv.innerHTML = selectedIds.map(id => {
            const conta = mockContas.find(c => c.id === id);
            return `<span class="selected-tag">${conta ? conta.label : id}<span class="remove-tag" data-id="${id}">&times;</span></span>`;
        }).join('');
        inputHidden.value = selectedIds.join(',');
    }
    // Inicial
    renderOptions();
    renderSelected();
    // Buscar
    contasSearch.addEventListener('input', e => renderOptions(e.target.value));
    // Selecionar/desselecionar
    contasOptionsDiv.addEventListener('mousedown', function(e) {
        if (e.target.classList.contains('dropdown-option')) {
            const id = e.target.getAttribute('data-id');
            if (selectedIds.includes(id)) {
                selectedIds = selectedIds.filter(x => x !== id);
            } else {
                selectedIds.push(id);
            }
            renderOptions(contasSearch.value);
            renderSelected();
        }
    });
    // Remover tag
    contasSelectedDiv.addEventListener('mousedown', function(e) {
        if (e.target.classList.contains('remove-tag')) {
            const id = e.target.getAttribute('data-id');
            selectedIds = selectedIds.filter(x => x !== id);
            renderOptions(contasSearch.value);
            renderSelected();
        }
    });
}

function preencherContasMock() {
    const select = document.getElementById('encContas');
    if (!select) return;
    select.innerHTML = mockContas.map(c => `<option value="${c.id}">${c.label}</option>`).join('');
}
function preencherGerentesMock(selectId) {
    const select = document.getElementById(selectId);
    if (!select) return;
    select.innerHTML = '<option value="">Selecione...</option>' +
        mockGerentes.map(g => `<option value="${g.id}">${g.name} (${g.email})</option>`).join('');
}

function setupTicketDetail() {
    const urlParams = new URLSearchParams(window.location.search);
    const ticketId = urlParams.get('id');
    
    if (ticketId) {
        loadTicketDetail(ticketId);
    } else {
        window.location.href = 'dashboard.html';
    }
}

// Authentication functions
function handleLogin(e) {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const email = formData.get('email');
    const password = formData.get('password');
    const role = formData.get('role');
    
    // Simulate login (in real app, this would be an API call)
    const user = authenticateUser(email, password, role);
    
    if (user) {
        setCurrentUser(user);
        window.location.href = 'dashboard.html';
    } else {
        alert('Credenciais inválidas. Tente novamente.');
    }
}

function authenticateUser(email, password, role) {
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const user = users.find(u => u.email === email && u.password === password && u.role === role);
    if (user) {
        return { id: user.id, name: user.name, email: user.email, role: user.role };
    }
    return null;
}

function setCurrentUser(user) {
    localStorage.setItem('currentUser', JSON.stringify(user));
    currentUser = user;
}

function getCurrentUser() {
    const user = localStorage.getItem('currentUser');
    return user ? JSON.parse(user) : null;
}

function logout() {
    localStorage.removeItem('currentUser');
    localStorage.removeItem('selectedCategory');
    window.location.href = 'index.html';
}

// Ticket management functions
function handleTicketSubmission(e) {
    e.preventDefault();
    const formData = new FormData(e.target);
    const selectedCategory = localStorage.getItem('selectedCategory');
    if (selectedCategory === 'encarteiramento') {
        // Dados do formulário de encarteiramento
        const tipoSolicitacao = formData.get('encTipoSolicitacao');
        const agencia = formData.get('encAgencia');
        const contas = formData.get('contasSelecionadas');
        const gerenteSolicitante = formData.get('encGerenteSolicitante');
        const gerenteCedente = formData.get('encGerenteCedente');
        const gerenteRegional = formData.get('encGerenteRegional');
        // Buscar e-mails dos gerentes (mock)
        const gerenteCedenteObj = mockGerentes.find(g => g.id === gerenteCedente);
        const gerenteRegionalObj = mockGerentes.find(g => g.id === gerenteRegional);
        // Montar payload
        const payload = {
            category: 'encarteiramento',
            tipoSolicitacao,
            agencia,
            contas,
            gerenteSolicitante,
            gerenteCedente,
            gerenteRegional,
            gerenteCedenteEmail: gerenteCedenteObj ? gerenteCedenteObj.email : '',
            gerenteRegionalEmail: gerenteRegionalObj ? gerenteRegionalObj.email : '',
            createdBy: currentUser.id
        };
        fetch('api/tickets.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                alert('Chamado criado e e-mail enviado com sucesso!');
                window.location.href = 'dashboard.html';
            } else {
                alert('Erro ao criar chamado: ' + (data.error || 'Erro desconhecido.'));
            }
        })
        .catch(() => alert('Erro ao conectar com o servidor.'));
        return;
    }
    
    const ticketData = {
        solicitationNumber: formData.get('solicitationNumber'),
        agency: formData.get('agency'),
        accountNumber: formData.get('accountNumber'),
        priority: formData.get('priority'),
        description: formData.get('description'),
        category: localStorage.getItem('selectedCategory'),
        categoryFields: getCategoryFieldsData(),
        attachments: formData.get('attachments'),
        createdBy: currentUser.id,
        createdAt: new Date().toISOString(),
        status: 'open'
    };
    
    // In real app, this would be an API call
    createTicket(ticketData);
    
    // Clear category selection
    localStorage.removeItem('selectedCategory');
    
    // Redirect to dashboard
    window.location.href = 'dashboard.html';
}

function createTicket(ticketData) {
    // Generate unique ID
    const ticketId = Date.now();
    const ticket = {
        id: ticketId,
        ...ticketData,
        interactions: [{
            type: 'created',
            user: currentUser.name,
            timestamp: new Date().toISOString(),
            comment: 'Ticket criado'
        }]
    };
    
    // Save to localStorage (in real app, this would be saved to database)
    const existingTickets = JSON.parse(localStorage.getItem('tickets') || '[]');
    existingTickets.push(ticket);
    localStorage.setItem('tickets', JSON.stringify(existingTickets));
    
    alert(`Ticket #${ticketId} criado com sucesso!`);
}

function loadTickets() {
    const allTickets = JSON.parse(localStorage.getItem('tickets') || '[]');
    
    // Filter tickets based on user role
    if (currentUser.role === 'requester') {
        tickets = allTickets.filter(ticket => ticket.createdBy === currentUser.id);
    } else if (currentUser.role === 'analyst') {
        tickets = allTickets.filter(ticket => ticket.assignedTo === currentUser.id || !ticket.assignedTo);
    } else {
        tickets = allTickets; // Admin sees all tickets
    }
    
    updateStats();
    renderTickets();
}

function updateStats() {
    const total = tickets.length;
    const open = tickets.filter(t => t.status === 'open').length;
    const progress = tickets.filter(t => t.status === 'progress').length;
    const resolved = tickets.filter(t => t.status === 'resolved').length;
    
    document.getElementById('totalTickets').textContent = total;
    document.getElementById('openTickets').textContent = open;
    document.getElementById('progressTickets').textContent = progress;
    document.getElementById('resolvedTickets').textContent = resolved;
}

function renderTickets() {
    const container = document.getElementById('ticketsContainer');
    if (!container) return;
    
    if (tickets.length === 0) {
        container.innerHTML = `
            <div class="text-center py-5">
                <i class="fas fa-inbox fa-3x text-muted mb-3"></i>
                <h4 class="text-muted">Nenhum ticket encontrado</h4>
                <p class="text-muted">Não há tickets para exibir no momento.</p>
            </div>
        `;
        return;
    }

    // Ordenar tickets do mais recente para o mais antigo
    const sortedTickets = [...tickets].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

    const ticketsHTML = sortedTickets.map(ticket => `
        <div class="dashboard-card">
            <div class="row align-items-center">
                <div class="col-md-1">
                    ${currentUser.role === 'analyst' ? `
                        <input type="checkbox" name="ticketSelect" value="${ticket.id}" class="form-check-input">
                    ` : ''}
                </div>
                <div class="col-md-2">
                    <strong>#${ticket.id}</strong>
                    <div class="text-muted small">${formatDate(ticket.createdAt)}</div>
                </div>
                <div class="col-md-3">
                    <div class="fw-bold">${ticket.solicitationNumber}</div>
                    <div class="text-muted small">${ticket.agency}</div>
                </div>
                <div class="col-md-2">
                    <span class="badge bg-primary">${getCategoryDisplayName(ticket.category)}</span>
                </div>
                <div class="col-md-2 text-end">
                    <button class="btn btn-sm btn-outline-primary" onclick="viewTicket(${ticket.id})">
                        <i class="fas fa-eye me-1"></i>Ver
                    </button>
                </div>
            </div>
        </div>
    `).join('');
    
    container.innerHTML = ticketsHTML;
}

function filterTickets() {
    loadTickets(); // Garante que tickets está atualizado
    const statusFilter = document.getElementById('statusFilter').value;
    const categoryFilter = document.getElementById('categoryFilter').value;
    const dateStart = document.getElementById('dateStartFilter').value;
    const dateEnd = document.getElementById('dateEndFilter').value;
    const analystFilter = document.getElementById('analystFilter');
    let filteredTickets = tickets;
    if (statusFilter) {
        filteredTickets = filteredTickets.filter(ticket => ticket.status === statusFilter);
    }
    if (categoryFilter) {
        filteredTickets = filteredTickets.filter(ticket => ticket.category === categoryFilter);
    }
    if (dateStart) {
        filteredTickets = filteredTickets.filter(ticket => new Date(ticket.createdAt) >= new Date(dateStart));
    }
    if (dateEnd) {
        filteredTickets = filteredTickets.filter(ticket => new Date(ticket.createdAt) <= new Date(dateEnd + 'T23:59:59'));
    }
    if (analystFilter && analystFilter.value) {
        filteredTickets = filteredTickets.filter(ticket => String(ticket.assignedTo) === analystFilter.value);
    }
    renderFilteredTickets(filteredTickets);
}

function renderFilteredTickets(filteredTickets) {
    const container = document.getElementById('ticketsContainer');
    if (!container) return;
    
    if (filteredTickets.length === 0) {
        container.innerHTML = `
            <div class="text-center py-5">
                <i class="fas fa-search fa-3x text-muted mb-3"></i>
                <h4 class="text-muted">Nenhum resultado encontrado</h4>
                <p class="text-muted">Tente ajustar os filtros.</p>
            </div>
        `;
        return;
    }

    // Ordenar tickets filtrados do mais recente para o mais antigo
    const sortedFiltered = [...filteredTickets].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

    const ticketsHTML = sortedFiltered.map(ticket => `
        <div class="dashboard-card">
            <div class="row align-items-center">
                <div class="col-md-1">
                    ${currentUser.role === 'analyst' ? `
                        <input type="checkbox" name="ticketSelect" value="${ticket.id}" class="form-check-input">
                    ` : ''}
                </div>
                <div class="col-md-2">
                    <strong>#${ticket.id}</strong>
                    <div class="text-muted small">${formatDate(ticket.createdAt)}</div>
                </div>
                <div class="col-md-3">
                    <div class="fw-bold">${ticket.solicitationNumber}</div>
                    <div class="text-muted small">${ticket.agency}</div>
                </div>
                <div class="col-md-2">
                    <span class="badge bg-primary">${getCategoryDisplayName(ticket.category)}</span>
                </div>
                <div class="col-md-2 text-end">
                    <button class="btn btn-sm btn-outline-primary" onclick="viewTicket(${ticket.id})">
                        <i class="fas fa-eye me-1"></i>Ver
                    </button>
                </div>
            </div>
        </div>
    `).join('');
    
    container.innerHTML = ticketsHTML;
}

// Category-specific functions
function loadCategoryFields(category) {
    const container = document.getElementById('categoryFields');
    if (!container) return;
    
    let fieldsHTML = '';
    
    switch (category) {
        case 'pade':
            fieldsHTML = `
                <div class="row mb-4">
                    <div class="col-md-6">
                        <label for="dataType" class="form-label">Tipo de Dados</label>
                        <select class="form-select" id="dataType" name="dataType" required>
                            <option value="">Selecione o tipo</option>
                            <option value="personal">Dados Pessoais</option>
                            <option value="financial">Dados Financeiros</option>
                            <option value="operational">Dados Operacionais</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label for="changeType" class="form-label">Tipo de Alteração</label>
                        <select class="form-select" id="changeType" name="changeType" required>
                            <option value="">Selecione o tipo</option>
                            <option value="insert">Inserção</option>
                            <option value="update">Atualização</option>
                            <option value="delete">Exclusão</option>
                        </select>
                    </div>
                </div>
            `;
            break;
            
        case 'meta':
            fieldsHTML = `
                <div class="row mb-4">
                    <div class="col-md-6">
                        <label for="metricType" class="form-label">Tipo de Métrica</label>
                        <select class="form-select" id="metricType" name="metricType" required>
                            <option value="">Selecione a métrica</option>
                            <option value="performance">Performance</option>
                            <option value="volume">Volume</option>
                            <option value="quality">Qualidade</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label for="timeframe" class="form-label">Período</label>
                        <select class="form-select" id="timeframe" name="timeframe" required>
                            <option value="">Selecione o período</option>
                            <option value="daily">Diário</option>
                            <option value="weekly">Semanal</option>
                            <option value="monthly">Mensal</option>
                        </select>
                    </div>
                </div>
            `;
            break;
            
        case 'encarteiramento':
            fieldsHTML = `
                <div class="row mb-4">
                    <div class="col-md-6">
                        <label for="exceptionType" class="form-label">Tipo de Exceção</label>
                        <select class="form-select" id="exceptionType" name="exceptionType" required>
                            <option value="">Selecione o tipo</option>
                            <option value="documentation">Documentação</option>
                            <option value="process">Processo</option>
                            <option value="system">Sistema</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label for="urgency" class="form-label">Urgência</label>
                        <select class="form-select" id="urgency" name="urgency" required>
                            <option value="">Selecione a urgência</option>
                            <option value="low">Baixa</option>
                            <option value="medium">Média</option>
                            <option value="high">Alta</option>
                            <option value="critical">Crítica</option>
                        </select>
                    </div>
                </div>
            `;
            break;
    }
    
    container.innerHTML = fieldsHTML;
}

function getCategoryFieldsData() {
    const category = localStorage.getItem('selectedCategory');
    const data = {};
    
    switch (category) {
        case 'pade':
            data.dataType = document.getElementById('dataType')?.value;
            data.changeType = document.getElementById('changeType')?.value;
            break;
        case 'meta':
            data.metricType = document.getElementById('metricType')?.value;
            data.timeframe = document.getElementById('timeframe')?.value;
            break;
        case 'encarteiramento':
            data.exceptionType = document.getElementById('exceptionType')?.value;
            data.urgency = document.getElementById('urgency')?.value;
            break;
    }
    
    return data;
}

// Ticket detail functions
function loadTicketDetail(ticketId) {
    const allTickets = JSON.parse(localStorage.getItem('tickets') || '[]');
    const ticket = allTickets.find(t => t.id == ticketId);
    
    if (!ticket) {
        alert('Ticket não encontrado');
        window.location.href = 'dashboard.html';
        return;
    }
    
    currentTicket = ticket;
    displayTicketDetails(ticket);
    renderTimeline(ticket);
    setupActionButtons(ticket);
}

function displayTicketDetails(ticket) {
    document.getElementById('ticketId').textContent = ticket.id;
    document.getElementById('ticketCreated').textContent = formatDate(ticket.createdAt);
    document.getElementById('ticketCreator').textContent = ticket.createdBy;
    document.getElementById('solicitationNumber').textContent = ticket.solicitationNumber;
    document.getElementById('agency').textContent = ticket.agency;
    document.getElementById('accountNumber').textContent = ticket.accountNumber;
    document.getElementById('category').textContent = getCategoryDisplayName(ticket.category);
    document.getElementById('description').textContent = ticket.description;
    
    // Update status and priority
    const statusElement = document.getElementById('ticketStatus');
    statusElement.className = `status-badge status-${ticket.status}`;
    statusElement.textContent = getStatusDisplayName(ticket.status);
    
    const priorityElement = document.getElementById('ticketPriority');
    priorityElement.textContent = getPriorityDisplayName(ticket.priority);
    priorityElement.className = `badge bg-${getPriorityColor(ticket.priority)}`;
    
    // Display category-specific fields
    displayCategoryFields(ticket);
}

function displayCategoryFields(ticket) {
    const container = document.getElementById('additionalFields');
    if (!container || !ticket.categoryFields) return;
    
    let fieldsHTML = '';
    
    switch (ticket.category) {
        case 'pade':
            fieldsHTML = `
                <div class="mb-3">
                    <strong>Tipo de Dados:</strong> ${getDataTypeDisplayName(ticket.categoryFields.dataType)}
                </div>
                <div class="mb-3">
                    <strong>Tipo de Alteração:</strong> ${getChangeTypeDisplayName(ticket.categoryFields.changeType)}
                </div>
            `;
            break;
        case 'meta':
            fieldsHTML = `
                <div class="mb-3">
                    <strong>Tipo de Métrica:</strong> ${getMetricTypeDisplayName(ticket.categoryFields.metricType)}
                </div>
                <div class="mb-3">
                    <strong>Período:</strong> ${getTimeframeDisplayName(ticket.categoryFields.timeframe)}
                </div>
            `;
            break;
        case 'encarteiramento':
            fieldsHTML = `
                <div class="mb-3">
                    <strong>Tipo de Exceção:</strong> ${getExceptionTypeDisplayName(ticket.categoryFields.exceptionType)}
                </div>
                <div class="mb-3">
                    <strong>Urgência:</strong> ${getUrgencyDisplayName(ticket.categoryFields.urgency)}
                </div>
            `;
            break;
    }
    
    container.innerHTML = fieldsHTML;
}

function renderTimeline(ticket) {
    const container = document.getElementById('timelineContainer');
    if (!container) return;
    
    const timelineHTML = ticket.interactions.map(interaction => `
        <div class="timeline-item">
            <div class="bg-white p-3 rounded shadow-soft">
                <div class="d-flex justify-content-between align-items-start mb-2">
                    <strong class="text-primary">${interaction.user}</strong>
                    <small class="text-muted">${formatDate(interaction.timestamp)}</small>
                </div>
                <div class="mb-2">
                    <span class="badge bg-secondary">${getInteractionTypeDisplayName(interaction.type)}</span>
                </div>
                ${interaction.comment ? `<p class="mb-0">${interaction.comment}</p>` : ''}
            </div>
        </div>
    `).join('');
    
    container.innerHTML = timelineHTML;
}

function setupActionButtons(ticket) {
    const assignBtn = document.getElementById('assignBtn');
    if (assignBtn && currentUser.role === 'admin') {
        assignBtn.style.display = 'inline-block';
    }
}

// Modal functions
function showUpdateModal() {
    const modal = new bootstrap.Modal(document.getElementById('updateStatusModal'));
    modal.show();
}

function showAssignModal() {
    // Preencher select de analistas
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const analysts = users.filter(u => u.role === 'analyst');
    const select = document.getElementById('assignedAnalyst');
    if (select) {
        select.innerHTML = '<option value="">Selecione um analista</option>' +
            analysts.map(a => `<option value="${a.id}">${a.name} (${a.email})</option>`).join('');
    }
    const modal = new bootstrap.Modal(document.getElementById('assignModal'));
    modal.show();
}

function showCommentModal() {
    const modal = new bootstrap.Modal(document.getElementById('commentModal'));
    modal.show();
}

function showBulkUpdateModal() {
    if (selectedTickets.length === 0) {
        alert('Selecione pelo menos um ticket para atualizar.');
        return;
    }
    const modal = new bootstrap.Modal(document.getElementById('bulkUpdateModal'));
    modal.show();
}

// Action functions
function updateTicketStatus() {
    const newStatus = document.getElementById('newStatus').value;
    const comment = document.getElementById('statusComment').value;
    
    if (!newStatus) {
        alert('Selecione um novo status.');
        return;
    }
    
    // Update ticket
    currentTicket.status = newStatus;
    currentTicket.interactions.push({
        type: 'status_change',
        user: currentUser.name,
        timestamp: new Date().toISOString(),
        comment: comment || `Status alterado para ${getStatusDisplayName(newStatus)}`
    });
    
    // Save to localStorage
    saveTicketUpdate(currentTicket);
    
    // Close modal and refresh
    bootstrap.Modal.getInstance(document.getElementById('updateStatusModal')).hide();
    displayTicketDetails(currentTicket);
    renderTimeline(currentTicket);
}

function assignTicket() {
    const analystId = document.getElementById('assignedAnalyst').value;
    const comment = document.getElementById('assignComment').value;
    
    if (!analystId) {
        alert('Selecione um analista.');
        return;
    }
    
    // Update ticket
    currentTicket.assignedTo = analystId;
    currentTicket.interactions.push({
        type: 'assigned',
        user: currentUser.name,
        timestamp: new Date().toISOString(),
        comment: comment || `Ticket atribuído ao analista`
    });
    
    // Save to localStorage
    saveTicketUpdate(currentTicket);
    
    // Close modal and refresh
    bootstrap.Modal.getInstance(document.getElementById('assignModal')).hide();
    displayTicketDetails(currentTicket);
    renderTimeline(currentTicket);
}

function addComment() {
    const comment = document.getElementById('newComment').value;
    
    if (!comment.trim()) {
        alert('Digite um comentário.');
        return;
    }
    
    // Add interaction
    currentTicket.interactions.push({
        type: 'comment',
        user: currentUser.name,
        timestamp: new Date().toISOString(),
        comment: comment
    });
    
    // Save to localStorage
    saveTicketUpdate(currentTicket);
    
    // Close modal and refresh
    bootstrap.Modal.getInstance(document.getElementById('commentModal')).hide();
    document.getElementById('newComment').value = '';
    renderTimeline(currentTicket);
}

function updateBulkStatus() {
    const newStatus = document.getElementById('bulkStatus').value;
    const comment = document.getElementById('bulkComment').value;
    if (!newStatus) {
        alert('Selecione um novo status.');
        return;
    }
    // Carregar todos os tickets uma vez
    const allTickets = JSON.parse(localStorage.getItem('tickets') || '[]');
    selectedTickets.forEach(ticketId => {
        const ticket = allTickets.find(t => t.id == ticketId);
        if (ticket) {
            ticket.status = newStatus;
            ticket.interactions.push({
                type: 'status_change',
                user: currentUser.name,
                timestamp: new Date().toISOString(),
                comment: comment || `Status alterado para ${getStatusDisplayName(newStatus)} (atualização em lote)`
            });
        }
    });
    // Salvar o array alterado
    localStorage.setItem('tickets', JSON.stringify(allTickets));
    // Fechar modal e atualizar tela
    bootstrap.Modal.getInstance(document.getElementById('bulkUpdateModal')).hide();
    selectedTickets = [];
    loadTickets();
}

function saveTicketUpdate(ticket) {
    const allTickets = JSON.parse(localStorage.getItem('tickets') || '[]');
    const index = allTickets.findIndex(t => t.id === ticket.id);
    
    if (index !== -1) {
        allTickets[index] = ticket;
        localStorage.setItem('tickets', JSON.stringify(allTickets));
    }
}

// Utility functions
function handleTicketSelection(checkbox) {
    if (checkbox.checked) {
        selectedTickets.push(checkbox.value);
    } else {
        selectedTickets = selectedTickets.filter(id => id !== checkbox.value);
    }
}

function viewTicket(ticketId) {
    window.location.href = `ticket-detail.html?id=${ticketId}`;
}

function createNewTicket() {
    window.location.href = 'index.html';
}

function refreshTickets() {
    loadTickets();
}

function loadInitialData() {
    // Load any initial data needed
}

// Display name functions
function getRoleDisplayName(role) {
    const roles = {
        'requester': 'Solicitante',
        'analyst': 'Analista',
        'admin': 'Administrador'
    };
    return roles[role] || role;
}

function getCategoryDisplayName(category) {
    const categories = {
        'pade': 'PADE',
        'meta': 'META',
        'encarteiramento': 'ENCARTEIRAMENTO POR EXCEÇÃO'
    };
    return categories[category] || category;
}

function getStatusDisplayName(status) {
    const statuses = {
        'open': 'Em Aberto',
        'progress': 'Em Progresso',
        'resolved': 'Resolvido'
    };
    return statuses[status] || status;
}

function getPriorityDisplayName(priority) {
    const priorities = {
        'low': 'Baixa',
        'medium': 'Média',
        'high': 'Alta',
        'urgent': 'Urgente'
    };
    return priorities[priority] || priority;
}

function getPriorityColor(priority) {
    const colors = {
        'low': 'success',
        'medium': 'warning',
        'high': 'danger',
        'urgent': 'danger'
    };
    return colors[priority] || 'secondary';
}

function getInteractionTypeDisplayName(type) {
    const types = {
        'created': 'Criado',
        'status_change': 'Mudança de Status',
        'assigned': 'Atribuído',
        'comment': 'Comentário'
    };
    return types[type] || type;
}

function getDataTypeDisplayName(type) {
    const types = {
        'personal': 'Dados Pessoais',
        'financial': 'Dados Financeiros',
        'operational': 'Dados Operacionais'
    };
    return types[type] || type;
}

function getChangeTypeDisplayName(type) {
    const types = {
        'insert': 'Inserção',
        'update': 'Atualização',
        'delete': 'Exclusão'
    };
    return types[type] || type;
}

function getMetricTypeDisplayName(type) {
    const types = {
        'performance': 'Performance',
        'volume': 'Volume',
        'quality': 'Qualidade'
    };
    return types[type] || type;
}

function getTimeframeDisplayName(type) {
    const types = {
        'daily': 'Diário',
        'weekly': 'Semanal',
        'monthly': 'Mensal'
    };
    return types[type] || type;
}

function getExceptionTypeDisplayName(type) {
    const types = {
        'documentation': 'Documentação',
        'process': 'Processo',
        'system': 'Sistema'
    };
    return types[type] || type;
}

function getUrgencyDisplayName(type) {
    const types = {
        'low': 'Baixa',
        'medium': 'Média',
        'high': 'Alta',
        'critical': 'Crítica'
    };
    return types[type] || type;
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

// Usuários de teste para facilitar login
function seedTestUsers() {
    if (!localStorage.getItem('testUsersSeeded')) {
        const users = [
            { id: 1, name: 'Solicitante', email: 'requester@test.com', password: '123456', role: 'requester' },
            { id: 2, name: 'Analista', email: 'analyst@test.com', password: '123456', role: 'analyst' },
            { id: 3, name: 'Administrador', email: 'admin@test.com', password: '123456', role: 'admin' },
            { id: 4, name: 'Ana Oliveira', email: 'analyst2@test.com', password: '1', role: 'analyst' }
        ];
        localStorage.setItem('users', JSON.stringify(users));
        localStorage.setItem('testUsersSeeded', '1');
    }
}

function requireAuth() {
    const user = getCurrentUser();
    if (!user) {
        window.location.href = 'login.html';
        return false;
    }
    document.body.classList.add('auth-ok');
    return true;
}

// Funções para a página POBJ
function setupPOBJ() {
    if (!currentUser) return;
    
    // Carregar dados iniciais
    loadIndicators();
    setupFilterDependencies();
    
    // Aplicar filtros iniciais
    applyFilters();
}

function loadIndicators() {
    // Dados mock para demonstração
    const mockIndicators = [
        {
            id: 1,
            cliente: 'Empresa ABC Ltda',
            agencia: 'Centro',
            gerente: 'João Silva',
            indicador: 'volume_captacao',
            meta: 1000000,
            realizado: 850000,
            diretor: 'sudeste',
            gerencia: 'comercial',
            periodo: '2024'
        },
        {
            id: 2,
            cliente: 'Comércio XYZ',
            agencia: 'Vila Nova',
            gerente: 'Maria Santos',
            indicador: 'clientes_engajados',
            meta: 150,
            realizado: 120,
            diretor: 'norte',
            gerencia: 'varejo',
            periodo: '2024'
        },
        {
            id: 3,
            cliente: 'Indústria DEF',
            agencia: 'Industrial',
            gerente: 'Pedro Costa',
            indicador: 'volume_captacao',
            meta: 2500000,
            realizado: 2600000,
            diretor: 'centro-oeste',
            gerencia: 'empresarial',
            periodo: '2024'
        },
        {
            id: 4,
            cliente: 'Serviços GHI',
            agencia: 'Centro',
            gerente: 'Ana Oliveira',
            indicador: 'produtividade',
            meta: 85,
            realizado: 78,
            diretor: 'sudeste',
            gerencia: 'comercial',
            periodo: '2024'
        }
    ];
    
    localStorage.setItem('indicators', JSON.stringify(mockIndicators));
}

function setupFilterDependencies() {
    // Populate gerencia filter based on diretor
    const diretorFilter = document.getElementById('diretorFilter');
    const gerenciaFilter = document.getElementById('gerenciaFilter');
    
    diretorFilter.addEventListener('change', function() {
        populateGerenciaFilter(this.value);
        populateAgenciaFilter('');
        populateGerenteFilter('');
    });
    
    // Populate agencia filter based on gerencia
    gerenciaFilter.addEventListener('change', function() {
        populateAgenciaFilter(this.value);
        populateGerenteFilter('');
    });
    
    // Populate gerente filter based on agencia
    const agenciaFilter = document.getElementById('agenciaFilter');
    agenciaFilter.addEventListener('change', function() {
        populateGerenteFilter(this.value);
    });
}

function populateGerenciaFilter(diretor) {
    const gerenciaFilter = document.getElementById('gerenciaFilter');
    const gerencias = {
        'norte': ['Varejo', 'Comercial'],
        'nordeste': ['Varejo', 'Comercial', 'Empresarial'],
        'centro-oeste': ['Varejo', 'Empresarial'],
        'sudeste': ['Varejo', 'Comercial', 'Empresarial'],
        'sul': ['Varejo', 'Comercial']
    };
    
    gerenciaFilter.innerHTML = '<option value="">Todas</option>';
    if (diretor && gerencias[diretor]) {
        gerencias[diretor].forEach(gerencia => {
            gerenciaFilter.innerHTML += `<option value="${gerencia.toLowerCase()}">${gerencia}</option>`;
        });
    }
}

function populateAgenciaFilter(gerencia) {
    const agenciaFilter = document.getElementById('agenciaFilter');
    const agencias = {
        'varejo': ['Centro', 'Vila Nova', 'Shopping'],
        'comercial': ['Centro', 'Industrial', 'Comercial'],
        'empresarial': ['Industrial', 'Empresarial', 'Centro']
    };
    
    agenciaFilter.innerHTML = '<option value="">Todas</option>';
    if (gerencia && agencias[gerencia]) {
        agencias[gerencia].forEach(agencia => {
            agenciaFilter.innerHTML += `<option value="${agencia}">${agencia}</option>`;
        });
    }
}

function populateGerenteFilter(agencia) {
    const gerenteFilter = document.getElementById('gerenteFilter');
    const gerentes = {
        'Centro': ['João Silva', 'Ana Oliveira'],
        'Vila Nova': ['Maria Santos'],
        'Industrial': ['Pedro Costa'],
        'Shopping': ['Carlos Mendes'],
        'Comercial': ['Fernanda Lima'],
        'Empresarial': ['Roberto Alves']
    };
    
    gerenteFilter.innerHTML = '<option value="">Todos</option>';
    if (agencia && gerentes[agencia]) {
        gerentes[agencia].forEach(gerente => {
            gerenteFilter.innerHTML += `<option value="${gerente}">${gerente}</option>`;
        });
    }
}

function applyFilters() {
    const diretor = document.getElementById('diretorFilter').value;
    const gerencia = document.getElementById('gerenciaFilter').value;
    const agencia = document.getElementById('agenciaFilter').value;
    const gerente = document.getElementById('gerenteFilter').value;
    const indicador = document.getElementById('indicadorFilter').value;
    const periodo = document.getElementById('periodoFilter').value;
    
    const allIndicators = JSON.parse(localStorage.getItem('indicators') || '[]');
    let filteredIndicators = allIndicators.filter(indicator => {
        if (diretor && indicator.diretor !== diretor) return false;
        if (gerencia && indicator.gerencia !== gerencia) return false;
        if (agencia && indicator.agencia !== agencia) return false;
        if (gerente && indicator.gerente !== gerente) return false;
        if (indicador && indicator.indicador !== indicador) return false;
        if (periodo && indicator.periodo !== periodo) return false;
        return true;
    });
    
    renderIndicators(filteredIndicators);
    updateSummaryCards(filteredIndicators);
}

function renderIndicators(indicators) {
    renderTableView(indicators);
    renderCardsView(indicators);
}

function renderTableView(indicators) {
    const tbody = document.getElementById('indicatorsTableBody');
    if (!tbody) return;
    
    if (indicators.length === 0) {
        tbody.innerHTML = '<tr><td colspan="9" class="text-center text-muted">Nenhum indicador encontrado</td></tr>';
        return;
    }
    
    const rows = indicators.map(indicator => {
        const percentual = Math.round((indicator.realizado / indicator.meta) * 100);
        const status = getStatusClass(percentual);
        const statusText = getStatusText(percentual);
        
        return `
            <tr>
                <td><strong>${indicator.cliente}</strong></td>
                <td>${indicator.agencia}</td>
                <td>${indicator.gerente}</td>
                <td>${getIndicadorDisplayName(indicator.indicador)}</td>
                <td>${formatCurrency(indicator.meta)}</td>
                <td>${formatCurrency(indicator.realizado)}</td>
                <td>
                    <div class="d-flex align-items-center">
                        <div class="progress me-2" style="width: 60px; height: 8px;">
                            <div class="progress-bar ${status}" style="width: ${Math.min(percentual, 100)}%"></div>
                        </div>
                        <span class="small">${percentual}%</span>
                    </div>
                </td>
                <td><span class="badge ${status}">${statusText}</span></td>
                <td>
                    <button class="btn btn-sm btn-outline-primary" onclick="showIndicatorDetail(${indicator.id})">
                        <i class="fas fa-eye"></i>
                    </button>
                </td>
            </tr>
        `;
    }).join('');
    
    tbody.innerHTML = rows;
}

function renderCardsView(indicators) {
    const container = document.getElementById('indicatorsCards');
    if (!container) return;
    
    if (indicators.length === 0) {
        container.innerHTML = '<div class="col-12 text-center text-muted">Nenhum indicador encontrado</div>';
        return;
    }
    
    const cards = indicators.map(indicator => {
        const percentual = Math.round((indicator.realizado / indicator.meta) * 100);
        const status = getStatusClass(percentual);
        const statusText = getStatusText(percentual);
        
        return `
            <div class="col-md-6 col-lg-4 mb-3">
                <div class="glass-card h-100">
                    <div class="d-flex justify-content-between align-items-start mb-2">
                        <h6 class="mb-0">${indicator.cliente}</h6>
                        <span class="badge ${status}">${statusText}</span>
                    </div>
                    <p class="text-muted small mb-2">${indicator.agencia} • ${indicator.gerente}</p>
                    <p class="mb-2"><strong>${getIndicadorDisplayName(indicator.indicador)}</strong></p>
                    <div class="mb-2">
                        <div class="d-flex justify-content-between small mb-1">
                            <span>Meta: ${formatCurrency(indicator.meta)}</span>
                            <span>Realizado: ${formatCurrency(indicator.realizado)}</span>
                        </div>
                        <div class="progress" style="height: 8px;">
                            <div class="progress-bar ${status}" style="width: ${Math.min(percentual, 100)}%"></div>
                        </div>
                    </div>
                    <div class="text-center">
                        <span class="h5 ${status}">${percentual}%</span>
                    </div>
                    <div class="text-center mt-2">
                        <button class="btn btn-sm btn-outline-primary" onclick="showIndicatorDetail(${indicator.id})">
                            <i class="fas fa-eye me-1"></i>Ver Detalhes
                        </button>
                    </div>
                </div>
            </div>
        `;
    }).join('');
    
    container.innerHTML = cards;
}

function updateSummaryCards(indicators) {
    const total = indicators.length;
    const atingidas = indicators.filter(i => (i.realizado / i.meta) >= 1).length;
    const emRisco = indicators.filter(i => {
        const percentual = i.realizado / i.meta;
        return percentual >= 0.7 && percentual < 1;
    }).length;
    const naoAtingidas = indicators.filter(i => (i.realizado / i.meta) < 0.7).length;
    
    document.getElementById('totalIndicators').textContent = total;
    document.getElementById('metasAtingidas').textContent = atingidas;
    document.getElementById('metasEmRisco').textContent = emRisco;
    document.getElementById('metasNaoAtingidas').textContent = naoAtingidas;
}

function getStatusClass(percentual) {
    if (percentual >= 100) return 'bg-success';
    if (percentual >= 70) return 'bg-warning';
    return 'bg-danger';
}

function getStatusText(percentual) {
    if (percentual >= 100) return 'Atingida';
    if (percentual >= 70) return 'Em Risco';
    return 'Não Atingida';
}

function getIndicadorDisplayName(indicador) {
    const indicadores = {
        'volume_captacao': 'Volume de Captação',
        'clientes_engajados': 'Clientes Engajados',
        'produtividade': 'Produtividade',
        'satisfacao': 'Satisfação do Cliente'
    };
    return indicadores[indicador] || indicador;
}

function formatCurrency(value) {
    if (typeof value === 'number') {
        if (value >= 1000000) {
            return `R$ ${(value / 1000000).toFixed(1)}M`;
        } else if (value >= 1000) {
            return `R$ ${(value / 1000).toFixed(0)}K`;
        }
        return `R$ ${value.toLocaleString()}`;
    }
    return value;
}

function toggleView(view) {
    const tableView = document.getElementById('tableView');
    const cardsView = document.getElementById('cardsView');
    
    if (view === 'table') {
        tableView.style.display = 'block';
        cardsView.style.display = 'none';
    } else {
        tableView.style.display = 'none';
        cardsView.style.display = 'block';
    }
}

function showIndicatorDetail(indicatorId) {
    const indicators = JSON.parse(localStorage.getItem('indicators') || '[]');
    const indicator = indicators.find(i => i.id === indicatorId);
    
    if (!indicator) return;
    
    const modal = document.getElementById('indicatorDetailModal');
    const content = document.getElementById('indicatorDetailContent');
    
    const percentual = Math.round((indicator.realizado / indicator.meta) * 100);
    const status = getStatusClass(percentual);
    const statusText = getStatusText(percentual);
    
    content.innerHTML = `
        <div class="row">
            <div class="col-md-6">
                <h6>Informações Gerais</h6>
                <p><strong>Cliente:</strong> ${indicator.cliente}</p>
                <p><strong>Agência:</strong> ${indicator.agencia}</p>
                <p><strong>Gerente:</strong> ${indicator.gerente}</p>
                <p><strong>Indicador:</strong> ${getIndicadorDisplayName(indicator.indicador)}</p>
                <p><strong>Período:</strong> ${indicator.periodo}</p>
            </div>
            <div class="col-md-6">
                <h6>Performance</h6>
                <div class="text-center mb-3">
                    <div class="h2 ${status}">${percentual}%</div>
                    <span class="badge ${status} fs-6">${statusText}</span>
                </div>
                <div class="row text-center">
                    <div class="col-6">
                        <div class="border rounded p-2">
                            <div class="h5 text-muted">Meta</div>
                            <div class="h4">${formatCurrency(indicator.meta)}</div>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="border rounded p-2">
                            <div class="h5 text-muted">Realizado</div>
                            <div class="h4 text-primary">${formatCurrency(indicator.realizado)}</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="mt-3">
            <h6>Análise</h6>
            <div class="progress mb-2" style="height: 20px;">
                <div class="progress-bar ${status}" style="width: ${Math.min(percentual, 100)}%"></div>
            </div>
            <p class="small text-muted">
                ${percentual >= 100 ? 'Meta superada! Parabéns!' : 
                  percentual >= 70 ? 'Meta em risco. Acompanhe de perto.' : 
                  'Meta não atingida. Necessita atenção imediata.'}
            </p>
        </div>
    `;
    
    const bootstrapModal = new bootstrap.Modal(modal);
    bootstrapModal.show();
}

function clearFilters() {
    document.getElementById('diretorFilter').value = '';
    document.getElementById('gerenciaFilter').value = '';
    document.getElementById('agenciaFilter').value = '';
    document.getElementById('gerenteFilter').value = '';
    document.getElementById('indicadorFilter').value = '';
    document.getElementById('periodoFilter').value = '2024';
    
    populateGerenciaFilter('');
    populateAgenciaFilter('');
    populateGerenteFilter('');
    
    applyFilters();
}

function refreshIndicators() {
    loadIndicators();
    applyFilters();
}

function exportToExcel() {
    // Implementação básica de exportação
    const indicators = JSON.parse(localStorage.getItem('indicators') || '[]');
    if (indicators.length === 0) {
        alert('Nenhum dado para exportar');
        return;
    }
    
    // Criar CSV básico
    let csv = 'Cliente,Agência,Gerente,Indicador,Meta,Realizado,% Atingido,Status\n';
    indicators.forEach(indicator => {
        const percentual = Math.round((indicator.realizado / indicator.meta) * 100);
        const status = getStatusText(percentual);
        csv += `"${indicator.cliente}","${indicator.agencia}","${indicator.gerente}","${getIndicadorDisplayName(indicator.indicador)}","${indicator.meta}","${indicator.realizado}","${percentual}%","${status}"\n`;
    });
    
    // Download do arquivo
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `indicadores_pobj_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

// Função para montar dinamicamente o menu superior em todas as páginas
function renderNavbar(activePage) {
    const user = getCurrentUser();
    const userName = user ? user.name : 'Usuário';
    const userRole = user ? user.role : '';
    const roleLabel = userRole ? ` <small>(${getRoleDisplayName(userRole)})</small>` : '';
    const nav = document.createElement('nav');
    nav.className = 'navbar navbar-expand-lg';
    nav.innerHTML = `
        <div class="container position-relative">
            <a class="navbar-brand d-flex align-items-center" href="index.html">
                <img src="img/logo.png" alt="Logo" width="36" height="36">
                Fale com a matriz!
            </a>
            <button class="navbar-toggler" type="button" aria-label="Menu" aria-expanded="false">
                <span class="fas fa-bars"></span>
            </button>
            <div class="navbar-nav ms-auto d-flex align-items-center">
                <a class="nav-link${activePage==='home' ? ' active' : ''}" href="index.html">Home</a>
                <a class="nav-link${activePage==='tickets' ? ' active' : ''}" href="dashboard.html#my-tickets">Meus chamados</a>
                <a class="nav-link${activePage==='pobj' ? ' active' : ''}" href="pobj.html">POBJ</a>
                <div class="dropdown ms-2">
                    <button class="btn btn-link navbar-user dropdown-toggle" type="button" id="userMenu" data-bs-toggle="dropdown" aria-expanded="false">
                        <span>${userName}${roleLabel}</span>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userMenu">
                        <li><a class="dropdown-item" href="#" onclick="logout()"><i class="fas fa-sign-out-alt me-2"></i>Log off</a></li>
                    </ul>
                </div>
            </div>
        </div>
    `;
    const body = document.body;
    body.insertBefore(nav, body.firstChild);

    // Responsividade: toggle menu
    const toggler = nav.querySelector('.navbar-toggler');
    const navLinks = nav.querySelector('.navbar-nav');
    if (toggler && navLinks) {
        toggler.addEventListener('click', function() {
            navLinks.classList.toggle('show');
            const expanded = navLinks.classList.contains('show');
            toggler.setAttribute('aria-expanded', expanded ? 'true' : 'false');
        });
    }
}
