<?php
require_once 'config.php';

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'POST':
        $data = getRequestData();
        
        if (isset($data['action'])) {
            switch ($data['action']) {
                case 'login':
                    handleLogin($data);
                    break;
                case 'logout':
                    handleLogout();
                    break;
                default:
                    sendJSONResponse(['error' => 'Invalid action'], 400);
            }
        } else {
            sendJSONResponse(['error' => 'Action required'], 400);
        }
        break;
        
    case 'GET':
        if (isset($_GET['action']) && $_GET['action'] === 'check') {
            checkAuth();
        } else {
            sendJSONResponse(['error' => 'Invalid action'], 400);
        }
        break;
        
    default:
        sendJSONResponse(['error' => 'Method not allowed'], 405);
}

function handleLogin($data) {
    validateRequiredFields($data, ['email', 'password', 'role']);
    
    $email = $data['email'];
    $password = $data['password'];
    $role = $data['role'];
    
    $user = authenticateUser($email, $password, $role);
    
    if ($user) {
        startSession();
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_role'] = $user['role'];
        
        sendJSONResponse([
            'success' => true,
            'user' => $user,
            'message' => 'Login successful'
        ]);
    } else {
        sendJSONResponse([
            'success' => false,
            'error' => 'Invalid credentials'
        ], 401);
    }
}

function handleLogout() {
    startSession();
    session_destroy();
    
    sendJSONResponse([
        'success' => true,
        'message' => 'Logout successful'
    ]);
}

function checkAuth() {
    if (isAuthenticated()) {
        $user = getCurrentUser();
        sendJSONResponse([
            'authenticated' => true,
            'user' => $user
        ]);
    } else {
        sendJSONResponse([
            'authenticated' => false
        ]);
    }
}
?> 