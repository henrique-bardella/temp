import pandas as pd
import logging
from tqdm import tqdm
import os
import zipfile
import yaml

########################## Load Configurations ##########################
data_incoming_foldername = 'data_incoming'
data_outgoing_foldername = 'data_outgoing'
log_foldername = 'logs'
log_filename = 'cnpj_merger.log'
config_foldername = 'config'
config_filename = 'config.yaml'

path_script = os.path.abspath(__file__)
path_script_dir = os.path.dirname(path_script)
path_project = os.path.dirname(path_script_dir)
path_incoming = os.path.join(path_project, data_incoming_foldername)
path_outgoing = os.path.join(path_project, data_outgoing_foldername)
path_log_dir = os.path.join(path_project, log_foldername)
path_log = os.path.join(path_log_dir, log_filename)
path_config_dir = os.path.join(path_project, config_foldername)
path_config = os.path.join(path_config_dir, config_filename)

# Ensure outgoing and log folders exist
os.makedirs(path_log_dir, exist_ok=True)
os.makedirs(path_outgoing, exist_ok=True)

with open(path_config, 'r') as file:
    config = yaml.safe_load(file)

csv_sep = config['csv_sep']
csv_dec = config['csv_dec']
csv_quote = config['csv_quote']
csv_enc = config['csv_enc']
export_format = config['export_format']

# Data types for each table
dtypes = config['dtypes']

########################## Helpers ##########################

def export_dataframe(df, export_path, mode='w', header=True):
    """Exports the DataFrame to the specified format with given mode."""
    export_format = export_path.split('.')[-1].lower()
    if export_format == "csv":
        df.to_csv(
            export_path, index=False, sep=csv_sep, encoding=csv_enc,
            quotechar=csv_quote, mode=mode, header=header
        )
    elif export_format == "parquet":
        # Observação: append com parquet depende do engine e versão do pandas/fastparquet.
        # Aqui mantive sua lógica original.
        if header:
            df.to_parquet(export_path, engine='fastparquet')
        else:
            df.to_parquet(export_path, engine='fastparquet', append=True)
    else:
        raise ValueError(f"Unsupported export format: {export_format}")

def normalize_str(s):
    """Normaliza strings para comparação de cabeçalho."""
    if pd.isna(s):
        return ""
    return str(s).strip().strip('"').strip("'").lower()

def looks_like_header(first_row, expected_cols):
    """
    Heurística: considera 'parecido com header' se:
    - todos os valores da primeira linha, normalizados, estão dentro do conjunto de colunas esperadas, e
    - pelo menos metade bate (para tolerar colunas vazias/ausentes).
    - Ou se a linha coincide exatamente com os nomes esperados na mesma ordem.
    """
    exp_norm = [normalize_str(c) for c in expected_cols]
    row_norm = [normalize_str(v) for v in first_row]

    # match exato por ordem
    if row_norm == exp_norm:
        return True

    exp_set = set(exp_norm)
    matches = sum(1 for v in row_norm if v in exp_set)
    return matches >= max(1, len(exp_norm) // 2)

########################## Main ##########################

logging.basicConfig(filename=path_log, level=logging.INFO,
                    format='%(asctime)s | %(name)s | %(levelname)s | %(message)s')
logging.info('Starting script')
tqdm.write('Starting script')

### Mapping incoming files
logging.info('Mapping incoming files')
tqdm.write('Mapping incoming files')

# Parameters for each table
file_params = {prefix: [] for prefix in dtypes.keys()}

# Crawling through directory and subdirectories to find ZIP files
for root, directories, files in os.walk(path_incoming):
    for filename in files:
        if filename.endswith(".zip"):
            file_with_no_ext = filename.split('.')[0]
            zip_file_path = os.path.join(root, filename)
            for prefix in file_params:
                if file_with_no_ext.startswith(prefix.title()):
                    file_params[prefix].append([zip_file_path, filename, file_with_no_ext])

logging.info(f'Executing File Processing')
tqdm.write(f'Executing File Processing')

# Processing and exporting files for all tables
for prefix, params in file_params.items():
    dtypes_var = dtypes[prefix]
    outgoing_file_path = os.path.join(path_outgoing, f"{prefix}.{export_format}")

    logging.info(f'Starting: {prefix}')
    tqdm.write(f'Starting: {prefix}')

    # Remove existing output file to avoid appending to old data
    if os.path.exists(outgoing_file_path):
        logging.info(f'Old target file exists. Removing from: {outgoing_file_path}')
        tqdm.write(f'Old target file exists. Removing from: {outgoing_file_path}')
        os.remove(outgoing_file_path)

    columns = list(dtypes_var.keys())
    is_first = True

    for file_list in params:
        zip_file_path = file_list[0]
        zip_filename = file_list[1]

        try:
            with zipfile.ZipFile(zip_file_path, 'r') as zip_ref:
                zip_file_list = zip_ref.namelist()
                if len(zip_file_list) == 1:
                    with zip_ref.open(zip_file_list[0]) as csvfile:
                        logging.info(f'Reading from ZIP: {zip_filename}')
                        tqdm.write(f'Reading from ZIP: {zip_filename}')

                        # Lê SEM header e aplica 'names=columns' sempre
                        df_buff = pd.read_csv(
                            csvfile,
                            header=None,
                            names=columns,
                            dtype=dtypes_var,
                            sep=csv_sep,
                            decimal=csv_dec,
                            quotechar=csv_quote,
                            encoding=csv_enc,
                            low_memory=False
                            # , nrows=10_000  # For testing
                        )

                        # Se a primeira linha "parece" ser o cabeçalho original do arquivo, descartá-la
                        if not df_buff.empty and looks_like_header(df_buff.iloc[0].tolist(), columns):
                            df_buff = df_buff.iloc[1:].reset_index(drop=True)
                            logging.info(f'Detected and removed header row in: {zip_filename}')
                            tqdm.write(f'Detected and removed header row in: {zip_filename}')

                    if is_first:
                        logging.info(f'Creating file {export_format}: {outgoing_file_path}')
                        tqdm.write(f'Creating file {export_format}: {outgoing_file_path}')
                    else:
                        logging.info(f'Appending to existing file {export_format}: {outgoing_file_path}')
                        tqdm.write(f'Appending to existing file {export_format}: {outgoing_file_path}')

                    # export_dataframe(df_buff, outgoing_file_path, header=is_first)
                    export_dataframe(
                        df_buff,
                        outgoing_file_path,
                        mode='w' if is_first else 'a',   # <-- AQUI
                        header=is_first
                    )
                    is_first = False

                else:
                    raise ValueError(f"ZIP file {zip_filename} contains more than one file.")

        except Exception as e:
            logging.error(f"Error processing {zip_filename}: {e}")
            tqdm.write(f"Error processing {zip_filename}: {e}")
