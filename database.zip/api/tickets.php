<?php
require_once 'config.php';

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        if (isset($_GET['id'])) {
            getTicket($_GET['id']);
        } else {
            getTickets();
        }
        break;
        
    case 'POST':
        createTicket();
        break;
        
    case 'PUT':
        if (isset($_GET['id'])) {
            updateTicket($_GET['id']);
        } else {
            sendJSONResponse(['error' => 'Ticket ID required'], 400);
        }
        break;
        
    case 'DELETE':
        if (isset($_GET['id'])) {
            deleteTicket($_GET['id']);
        } else {
            sendJSONResponse(['error' => 'Ticket ID required'], 400);
        }
        break;
        
    default:
        sendJSONResponse(['error' => 'Method not allowed'], 405);
}

function getTickets() {
    requireAuth();
    $user = getCurrentUser();
    $pdo = getDBConnection();
    
    // Build query based on user role
    $sql = "
        SELECT t.*, u.name as creator_name, a.name as assigned_name
        FROM tickets t
        LEFT JOIN users u ON t.created_by = u.id
        LEFT JOIN users a ON t.assigned_to = a.id
    ";
    
    $params = [];
    
    if ($user['role'] === 'requester') {
        $sql .= " WHERE t.created_by = ?";
        $params[] = $user['id'];
    } elseif ($user['role'] === 'analyst') {
        $sql .= " WHERE t.assigned_to = ? OR t.assigned_to IS NULL";
        $params[] = $user['id'];
    }
    // Admin sees all tickets
    
    $sql .= " ORDER BY t.created_at DESC";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $tickets = $stmt->fetchAll();
    
    // Get interactions for each ticket
    foreach ($tickets as &$ticket) {
        $ticket['interactions'] = getTicketInteractions($ticket['id']);
    }
    
    sendJSONResponse([
        'success' => true,
        'tickets' => $tickets
    ]);
}

function getTicket($id) {
    requireAuth();
    $user = getCurrentUser();
    $pdo = getDBConnection();
    
    $sql = "
        SELECT t.*, u.name as creator_name, a.name as assigned_name
        FROM tickets t
        LEFT JOIN users u ON t.created_by = u.id
        LEFT JOIN users a ON t.assigned_to = a.id
        WHERE t.id = ?
    ";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$id]);
    $ticket = $stmt->fetch();
    
    if (!$ticket) {
        sendJSONResponse(['error' => 'Ticket not found'], 404);
    }
    
    // Check permissions
    if ($user['role'] === 'requester' && $ticket['created_by'] !== $user['id']) {
        sendJSONResponse(['error' => 'Access denied'], 403);
    }
    
    // Get interactions
    $ticket['interactions'] = getTicketInteractions($id);
    
    sendJSONResponse([
        'success' => true,
        'ticket' => $ticket
    ]);
}

function createTicket() {
    requireAuth();
    $user = getCurrentUser();
    $data = getRequestData();
    
    validateRequiredFields($data, [
        'solicitation_number', 'agency', 'account_number', 
        'description', 'category'
    ]);
    
    $pdo = getDBConnection();
    
    try {
        $pdo->beginTransaction();
        
        $sql = "
            INSERT INTO tickets (
                solicitation_number, agency, account_number, priority,
                description, category, category_fields, created_by,
                status, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'open', GETDATE())
        ";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            $data['solicitation_number'],
            $data['agency'],
            $data['account_number'],
            $data['priority'] ?? 'medium',
            $data['description'],
            $data['category'],
            json_encode($data['category_fields'] ?? []),
            $user['id']
        ]);
        
        $ticketId = $pdo->lastInsertId();
        
        // Add initial interaction
        addTicketInteraction($ticketId, 'created', $user['id'], 'Ticket criado');
        
        $pdo->commit();
        
        sendJSONResponse([
            'success' => true,
            'ticket_id' => $ticketId,
            'message' => 'Ticket created successfully'
        ]);
        
    } catch (Exception $e) {
        $pdo->rollBack();
        sendJSONResponse(['error' => 'Failed to create ticket: ' . $e->getMessage()], 500);
    }
}

function updateTicket($id) {
    requireAuth();
    $user = getCurrentUser();
    $data = getRequestData();
    
    $pdo = getDBConnection();
    
    // Check if ticket exists and user has permission
    $stmt = $pdo->prepare("SELECT * FROM tickets WHERE id = ?");
    $stmt->execute([$id]);
    $ticket = $stmt->fetch();
    
    if (!$ticket) {
        sendJSONResponse(['error' => 'Ticket not found'], 404);
    }
    
    // Check permissions
    if ($user['role'] === 'requester' && $ticket['created_by'] !== $user['id']) {
        sendJSONResponse(['error' => 'Access denied'], 403);
    }
    
    try {
        $pdo->beginTransaction();
        
        $updateFields = [];
        $params = [];
        
        // Updateable fields
        $updatableFields = ['status', 'priority', 'assigned_to', 'description'];
        
        foreach ($updatableFields as $field) {
            if (isset($data[$field])) {
                $updateFields[] = "$field = ?";
                $params[] = $data[$field];
            }
        }
        
        if (empty($updateFields)) {
            sendJSONResponse(['error' => 'No fields to update'], 400);
        }
        
        $updateFields[] = "updated_at = GETDATE()";
        $params[] = $id;
        
        $sql = "UPDATE tickets SET " . implode(', ', $updateFields) . " WHERE id = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        
        // Add interaction for status change
        if (isset($data['status']) && $data['status'] !== $ticket['status']) {
            $comment = $data['status_comment'] ?? "Status alterado para " . getStatusDisplayName($data['status']);
            addTicketInteraction($id, 'status_change', $user['id'], $comment);
        }
        
        // Add interaction for assignment
        if (isset($data['assigned_to']) && $data['assigned_to'] !== $ticket['assigned_to']) {
            $comment = $data['assign_comment'] ?? "Ticket atribuído ao analista";
            addTicketInteraction($id, 'assigned', $user['id'], $comment);
        }
        
        $pdo->commit();
        
        sendJSONResponse([
            'success' => true,
            'message' => 'Ticket updated successfully'
        ]);
        
    } catch (Exception $e) {
        $pdo->rollBack();
        sendJSONResponse(['error' => 'Failed to update ticket: ' . $e->getMessage()], 500);
    }
}

function deleteTicket($id) {
    requireRole('admin');
    $pdo = getDBConnection();
    
    try {
        $pdo->beginTransaction();
        
        // Delete interactions first
        $stmt = $pdo->prepare("DELETE FROM ticket_interactions WHERE ticket_id = ?");
        $stmt->execute([$id]);
        
        // Delete ticket
        $stmt = $pdo->prepare("DELETE FROM tickets WHERE id = ?");
        $stmt->execute([$id]);
        
        if ($stmt->rowCount() === 0) {
            sendJSONResponse(['error' => 'Ticket not found'], 404);
        }
        
        $pdo->commit();
        
        sendJSONResponse([
            'success' => true,
            'message' => 'Ticket deleted successfully'
        ]);
        
    } catch (Exception $e) {
        $pdo->rollBack();
        sendJSONResponse(['error' => 'Failed to delete ticket: ' . $e->getMessage()], 500);
    }
}

function getTicketInteractions($ticketId) {
    $pdo = getDBConnection();
    
    $sql = "
        SELECT ti.*, u.name as user_name
        FROM ticket_interactions ti
        LEFT JOIN users u ON ti.user_id = u.id
        WHERE ti.ticket_id = ?
        ORDER BY ti.created_at ASC
    ";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$ticketId]);
    return $stmt->fetchAll();
}

function addTicketInteraction($ticketId, $type, $userId, $comment = null) {
    $pdo = getDBConnection();
    
    $sql = "
        INSERT INTO ticket_interactions (ticket_id, type, user_id, comment, created_at)
        VALUES (?, ?, ?, ?, GETDATE())
    ";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$ticketId, $type, $userId, $comment]);
}

function getStatusDisplayName($status) {
    $statuses = [
        'open' => 'Em Aberto',
        'progress' => 'Em Progresso',
        'resolved' => 'Resolvido'
    ];
    return $statuses[$status] ?? $status;
}
?> 