# Sistema de Tickets - Ticket Registration System

Um sistema moderno e elegante de registro de tickets com roles de usuário e workflows condicionais, desenvolvido com HTML, CSS, JavaScript, Bootstrap e PHP 7.1 com SQL Server.

## 🎨 Design

O sistema foi projetado seguindo os princípios de design da Apple e Dieter Rams:
- **Simplicidade e Clareza**: Layout limpo e intuitivo
- **Alta Qualidade Estética**: Paleta de cores refinada com tons neutros e acentos sutis
- **Função sobre Forma**: Todas as escolhas de design priorizam usabilidade
- **Precisão nos Detalhes**: Atenção cuidadosa a cada elemento
- **Design Centrado no Humano**: Experiência responsiva e acessível

### Paleta de Cores
- `#972D7A` - Primary (Roxo principal)
- `#AF286F` - Secondary (Rosa escuro)
- `#FDFBFC` - White (Branco)
- `#CC1E5F` - Accent (Rosa vibrante)
- `#7F3586` - Purple (Roxo médio)
- `#613A93` - Dark Purple (Roxo escuro)
- `#EB164F` - Red (Vermelho)
- `#46409D` - Dark Blue (Azul escuro)
- `#2445A7` - Blue (Azul)

## 🚀 Funcionalidades

### 1. Sistema de Triage
- Seleção de categoria: PADE, META, ENCARTEIRAMENTO POR EXCEÇÃO
- Redirecionamento para formulários específicos por categoria

### 2. Formulários Dinâmicos
- Campos obrigatórios: Número da Solicitação, Agência, Número da Conta
- Campos específicos por categoria
- Upload de anexos
- Validação em tempo real

### 3. Dashboard Adaptativo
- **Solicitante**: Visualiza apenas seus próprios tickets
- **Analista**: Visualiza tickets atribuídos + atualização em lote
- **Administrador**: Acesso completo ao sistema

### 4. Timeline Interativo
- Histórico cronológico de todas as interações
- Comentários, mudanças de status, atribuições
- Interface visual elegante

### 5. Sistema de Roles
- **Requester**: Criar tickets e acompanhar status
- **Analyst**: Gerenciar tickets atribuídos, atualização em lote
- **Admin**: Acesso total, gerenciamento de usuários

## 📁 Estrutura do Projeto

```
ticket-system/
├── index.html              # Página de triage
├── login.html              # Página de login
├── dashboard.html          # Dashboard principal
├── ticket-form.html        # Formulário de criação
├── ticket-detail.html      # Detalhes do ticket
├── css/
│   └── style.css           # Estilos principais
├── js/
│   └── app.js              # JavaScript principal
├── api/
│   ├── config.php          # Configuração do banco
│   ├── auth.php            # Autenticação
│   └── tickets.php         # API de tickets
└── database/
    └── schema.sql          # Schema do banco de dados
```

## 🛠️ Instalação

### Pré-requisitos
- PHP 7.1 ou superior
- SQL Server 2012 ou superior
- Servidor web (Apache/Nginx)
- Extensão PHP SQL Server

### 1. Configuração do Banco de Dados

```sql
-- Execute o arquivo database/schema.sql no SQL Server
-- Isso criará o banco de dados e as tabelas necessárias
```

### 2. Configuração do PHP

Edite o arquivo `api/config.php`:

```php
define('DB_HOST', 'localhost');        // Seu servidor SQL Server
define('DB_NAME', 'ticket_system');    // Nome do banco
define('DB_USER', 'seu_usuario');      // Usuário do banco
define('DB_PASS', 'sua_senha');        // Senha do banco
```

### 3. Configuração do Servidor Web

Configure seu servidor web para servir os arquivos estáticos e processar PHP.

### 4. Permissões de Arquivo

Certifique-se de que o diretório de uploads (se usado) tenha permissões de escrita.

## 👥 Usuários Padrão

O sistema vem com usuários de exemplo:

| Email | Senha | Role |
|-------|-------|------|
| requester@test.com | password123 | Solicitante |
| analyst@test.com | password123 | Analista |
| admin@test.com | password123 | Administrador |

## 🎯 Como Usar

### 1. Acesso ao Sistema
1. Acesse `index.html`
2. Clique em "Acessar Sistema"
3. Faça login com as credenciais

### 2. Criação de Ticket
1. Selecione uma categoria no triage
2. Preencha o formulário específico
3. Envie o ticket

### 3. Gerenciamento de Tickets
- **Solicitante**: Visualiza e acompanha seus tickets
- **Analista**: Atualiza status e adiciona comentários
- **Admin**: Atribui analistas e gerencia o sistema

## 🔧 API Endpoints

### Autenticação
- `POST /api/auth.php` - Login/Logout
- `GET /api/auth.php?action=check` - Verificar autenticação

### Tickets
- `GET /api/tickets.php` - Listar tickets
- `GET /api/tickets.php?id=X` - Obter ticket específico
- `POST /api/tickets.php` - Criar ticket
- `PUT /api/tickets.php?id=X` - Atualizar ticket
- `DELETE /api/tickets.php?id=X` - Deletar ticket

## 🎨 Personalização

### Cores
Edite as variáveis CSS em `css/style.css`:

```css
:root {
    --primary: #972D7A;
    --secondary: #AF286F;
    /* ... outras cores */
}
```

### Categorias
Para adicionar novas categorias, edite:
1. `index.html` - Adicione o card da categoria
2. `js/app.js` - Adicione a lógica específica
3. `database/schema.sql` - Atualize as constraints

## 🔒 Segurança

- Autenticação baseada em sessão
- Validação de entrada em todos os endpoints
- Sanitização de dados
- Controle de acesso baseado em roles
- Prepared statements para prevenir SQL injection

## 📱 Responsividade

O sistema é totalmente responsivo e funciona em:
- Desktop (1920px+)
- Tablet (768px - 1024px)
- Mobile (320px - 767px)

## 🚀 Performance

- Índices otimizados no banco de dados
- Lazy loading de componentes
- Minificação de assets (recomendado para produção)
- Cache de consultas frequentes

## 🐛 Troubleshooting

### Problemas Comuns

1. **Erro de Conexão com Banco**
   - Verifique as credenciais em `api/config.php`
   - Confirme se o SQL Server está rodando

2. **Página não Carrega**
   - Verifique se o servidor web está configurado
   - Confirme se o PHP está instalado

3. **Upload de Arquivos não Funciona**
   - Verifique as permissões do diretório
   - Confirme o `upload_max_filesize` no PHP

## 📄 Licença

Este projeto é de uso livre para fins educacionais e comerciais.

## 🤝 Contribuição

1. Fork o projeto
2. Crie uma branch para sua feature
3. Commit suas mudanças
4. Push para a branch
5. Abra um Pull Request

## 📞 Suporte

Para suporte técnico ou dúvidas, entre em contato através dos canais disponíveis.

---

**Desenvolvido com ❤️ seguindo os princípios de design da Apple e Dieter Rams** 