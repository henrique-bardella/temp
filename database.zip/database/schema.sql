-- Ticket System Database Schema for SQL Server
-- Create database
IF NOT EXISTS (SELECT * FROM sys.databases WHERE name = 'ticket_system')
BEGIN
    CREATE DATABASE ticket_system;
END
GO

USE ticket_system;
GO

-- Users table
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[users]') AND type in (N'U'))
BEGIN
    CREATE TABLE users (
        id INT IDENTITY(1,1) PRIMARY KEY,
        name NVARCHAR(255) NOT NULL,
        email NVARCHAR(255) NOT NULL UNIQUE,
        password_hash NVARCHAR(255) NOT NULL,
        role NVARCHAR(50) NOT NULL CHECK (role IN ('requester', 'analyst', 'admin')),
        is_active BIT DEFAULT 1,
        created_at DATETIME2 DEFAULT GETDATE(),
        updated_at DATETIME2 DEFAULT GETDATE()
    );
END
GO

-- Tickets table
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tickets]') AND type in (N'U'))
BEGIN
    CREATE TABLE tickets (
        id INT IDENTITY(1,1) PRIMARY KEY,
        solicitation_number NVARCHAR(100) NOT NULL,
        agency NVARCHAR(255) NOT NULL,
        account_number NVARCHAR(100) NOT NULL,
        priority NVARCHAR(20) DEFAULT 'medium' CHECK (priority IN ('low', 'medium', 'high', 'urgent')),
        description NTEXT NOT NULL,
        category NVARCHAR(50) NOT NULL CHECK (category IN ('pade', 'meta', 'encarteiramento')),
        category_fields NVARCHAR(MAX), -- JSON field for category-specific data
        status NVARCHAR(20) DEFAULT 'open' CHECK (status IN ('open', 'progress', 'resolved')),
        created_by INT NOT NULL,
        assigned_to INT,
        created_at DATETIME2 DEFAULT GETDATE(),
        updated_at DATETIME2 DEFAULT GETDATE(),
        FOREIGN KEY (created_by) REFERENCES users(id),
        FOREIGN KEY (assigned_to) REFERENCES users(id)
    );
END
GO

-- Ticket interactions table
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ticket_interactions]') AND type in (N'U'))
BEGIN
    CREATE TABLE ticket_interactions (
        id INT IDENTITY(1,1) PRIMARY KEY,
        ticket_id INT NOT NULL,
        type NVARCHAR(50) NOT NULL CHECK (type IN ('created', 'status_change', 'assigned', 'comment')),
        user_id INT NOT NULL,
        comment NTEXT,
        created_at DATETIME2 DEFAULT GETDATE(),
        FOREIGN KEY (ticket_id) REFERENCES tickets(id) ON DELETE CASCADE,
        FOREIGN KEY (user_id) REFERENCES users(id)
    );
END
GO

-- Ticket attachments table
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ticket_attachments]') AND type in (N'U'))
BEGIN
    CREATE TABLE ticket_attachments (
        id INT IDENTITY(1,1) PRIMARY KEY,
        ticket_id INT NOT NULL,
        filename NVARCHAR(255) NOT NULL,
        original_filename NVARCHAR(255) NOT NULL,
        file_path NVARCHAR(500) NOT NULL,
        file_size INT NOT NULL,
        mime_type NVARCHAR(100),
        uploaded_by INT NOT NULL,
        uploaded_at DATETIME2 DEFAULT GETDATE(),
        FOREIGN KEY (ticket_id) REFERENCES tickets(id) ON DELETE CASCADE,
        FOREIGN KEY (uploaded_by) REFERENCES users(id)
    );
END
GO

-- Create indexes for better performance
CREATE INDEX IX_tickets_created_by ON tickets(created_by);
CREATE INDEX IX_tickets_assigned_to ON tickets(assigned_to);
CREATE INDEX IX_tickets_status ON tickets(status);
CREATE INDEX IX_tickets_category ON tickets(category);
CREATE INDEX IX_tickets_created_at ON tickets(created_at);
CREATE INDEX IX_ticket_interactions_ticket_id ON ticket_interactions(ticket_id);
CREATE INDEX IX_ticket_interactions_created_at ON ticket_interactions(created_at);
CREATE INDEX IX_users_email ON users(email);
CREATE INDEX IX_users_role ON users(role);

-- Insert sample data
-- Sample users (password: 'password123' hashed with password_hash)
INSERT INTO users (name, email, password_hash, role) VALUES
('Solicitante', 'requester@test.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'requester'),
('Analista', 'analyst@test.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'analyst'),
('Pedro Costa', 'admin@test.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin'),
('Analista 2', 'analyst2@test.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'analyst'),
('Solicitante 2', 'requester2@test.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'requester');

-- Sample tickets
INSERT INTO tickets (solicitation_number, agency, account_number, priority, description, category, category_fields, created_by, status) VALUES
('SOL001', 'Agência Central', 'ACC123456', 'medium', 'Solicitação de alteração de dados pessoais do cliente', 'pade', '{"dataType": "personal", "changeType": "update"}', 1, 'open'),
('SOL002', 'Agência Norte', 'ACC789012', 'high', 'Monitoramento de performance do sistema de transações', 'meta', '{"metricType": "performance", "timeframe": "daily"}', 1, 'progress'),
('SOL003', 'Agência Sul', 'ACC345678', 'urgent', 'Processamento de exceção no sistema de encarteiramento', 'encarteiramento', '{"exceptionType": "system", "urgency": "critical"}', 5, 'open'),
('SOL004', 'Agência Leste', 'ACC901234', 'low', 'Atualização de dados financeiros', 'pade', '{"dataType": "financial", "changeType": "insert"}', 5, 'resolved'),
('SOL005', 'Agência Oeste', 'ACC567890', 'medium', 'Análise de volume de transações mensais', 'meta', '{"metricType": "volume", "timeframe": "monthly"}', 1, 'open');

-- Sample ticket interactions
INSERT INTO ticket_interactions (ticket_id, type, user_id, comment) VALUES
(1, 'created', 1, 'Ticket criado'),
(2, 'created', 1, 'Ticket criado'),
(2, 'assigned', 3, 'Ticket atribuído ao analista Maria Santos'),
(2, 'status_change', 2, 'Iniciando análise do sistema'),
(3, 'created', 5, 'Ticket criado'),
(4, 'created', 5, 'Ticket criado'),
(4, 'assigned', 4, 'Ticket atribuído ao analista Ana Oliveira'),
(4, 'status_change', 4, 'Processando alteração'),
(4, 'status_change', 4, 'Alteração concluída com sucesso'),
(5, 'created', 1, 'Ticket criado');

-- Update some tickets to have assigned analysts
UPDATE tickets SET assigned_to = 2 WHERE id = 2;
UPDATE tickets SET assigned_to = 4 WHERE id = 4;

GO

-- Create stored procedures for common operations

-- Procedure to get tickets with filters
CREATE OR ALTER PROCEDURE GetTicketsWithFilters
    @UserId INT,
    @UserRole NVARCHAR(50),
    @Status NVARCHAR(20) = NULL,
    @Category NVARCHAR(50) = NULL
AS
BEGIN
    DECLARE @SQL NVARCHAR(MAX) = '
        SELECT t.*, u.name as creator_name, a.name as assigned_name
        FROM tickets t
        LEFT JOIN users u ON t.created_by = u.id
        LEFT JOIN users a ON t.assigned_to = a.id
        WHERE 1=1';
    
    -- Add role-based filtering
    IF @UserRole = 'requester'
        SET @SQL = @SQL + ' AND t.created_by = ' + CAST(@UserId AS NVARCHAR(10));
    ELSE IF @UserRole = 'analyst'
        SET @SQL = @SQL + ' AND (t.assigned_to = ' + CAST(@UserId AS NVARCHAR(10)) + ' OR t.assigned_to IS NULL)';
    
    -- Add optional filters
    IF @Status IS NOT NULL
        SET @SQL = @SQL + ' AND t.status = ''' + @Status + '''';
    
    IF @Category IS NOT NULL
        SET @SQL = @SQL + ' AND t.category = ''' + @Category + '''';
    
    SET @SQL = @SQL + ' ORDER BY t.created_at DESC';
    
    EXEC sp_executesql @SQL;
END
GO

-- Procedure to get ticket statistics
CREATE OR ALTER PROCEDURE GetTicketStats
    @UserId INT,
    @UserRole NVARCHAR(50)
AS
BEGIN
    DECLARE @SQL NVARCHAR(MAX) = '
        SELECT 
            COUNT(*) as total,
            SUM(CASE WHEN status = ''open'' THEN 1 ELSE 0 END) as open_count,
            SUM(CASE WHEN status = ''progress'' THEN 1 ELSE 0 END) as progress_count,
            SUM(CASE WHEN status = ''resolved'' THEN 1 ELSE 0 END) as resolved_count
        FROM tickets
        WHERE 1=1';
    
    -- Add role-based filtering
    IF @UserRole = 'requester'
        SET @SQL = @SQL + ' AND created_by = ' + CAST(@UserId AS NVARCHAR(10));
    ELSE IF @UserRole = 'analyst'
        SET @SQL = @SQL + ' AND (assigned_to = ' + CAST(@UserId AS NVARCHAR(10)) + ' OR assigned_to IS NULL)';
    
    EXEC sp_executesql @SQL;
END
GO

-- Procedure to add ticket interaction
CREATE OR ALTER PROCEDURE AddTicketInteraction
    @TicketId INT,
    @Type NVARCHAR(50),
    @UserId INT,
    @Comment NTEXT = NULL
AS
BEGIN
    INSERT INTO ticket_interactions (ticket_id, type, user_id, comment, created_at)
    VALUES (@TicketId, @Type, @UserId, @Comment, GETDATE());
    
    -- Update ticket updated_at timestamp
    UPDATE tickets SET updated_at = GETDATE() WHERE id = @TicketId;
END
GO

PRINT 'Database schema created successfully!';
PRINT 'Sample data inserted.';
PRINT 'Stored procedures created.';
PRINT '';
PRINT 'Default login credentials:';
PRINT 'Requester: requester@test.com / password123';
PRINT 'Analyst: analyst@test.com / password123';
PRINT 'Admin: admin@test.com / password123'; 