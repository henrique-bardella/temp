// Global variables
let currentUser = null;
let currentTicket = null;
let tickets = [];
let selectedTickets = [];

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

function initializeApp() {
    seedTestUsers();
    // Check if user is logged in
    const user = getCurrentUser();
    if (user) {
        currentUser = user;
        setupPageBasedOnRole();
    }

    // Setup event listeners
    setupEventListeners();
    
    // Load initial data
    loadInitialData();
}

function setupEventListeners() {
    // Category selection on triage page
    const categoryCards = document.querySelectorAll('.category-card');
    categoryCards.forEach(card => {
        card.addEventListener('click', function() {
            const category = this.dataset.category;
            localStorage.setItem('selectedCategory', category);
            window.location.href = 'ticket-form.html';
        });
    });

    // Login form
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }

    // Ticket form
    const ticketForm = document.getElementById('ticketForm');
    if (ticketForm) {
        ticketForm.addEventListener('submit', handleTicketSubmission);
    }

    // Dashboard filters
    const statusFilter = document.getElementById('statusFilter');
    const categoryFilter = document.getElementById('categoryFilter');
    if (statusFilter) statusFilter.addEventListener('change', filterTickets);
    if (categoryFilter) categoryFilter.addEventListener('change', filterTickets);

    // Checkbox selection for bulk operations
    document.addEventListener('change', function(e) {
        if (e.target.type === 'checkbox' && e.target.name === 'ticketSelect') {
            handleTicketSelection(e.target);
        }
    });
}

function setupPageBasedOnRole() {
    const currentPage = window.location.pathname.split('/').pop();
    
    if (currentPage === 'dashboard.html') {
        setupDashboard();
    } else if (currentPage === 'ticket-form.html') {
        setupTicketForm();
    } else if (currentPage === 'ticket-detail.html') {
        setupTicketDetail();
    }
}

function setupDashboard() {
    if (!currentUser) return;
    // Atualizar nome do usuário no header
    const userNameEl = document.getElementById('welcomeUserName');
    if (userNameEl) userNameEl.textContent = currentUser.name;
    // Mostrar filtro de analista só para admin
    if (currentUser.role === 'admin') {
        document.querySelectorAll('.admin-only').forEach(el => el.style.display = 'block');
        preencherFiltroAnalista();
    }
    // Filtros de data já estão sempre visíveis para admin e analista (HTML)
    // Show/hide elements based on role
    const bulkUpdateBtn = document.getElementById('bulkUpdateBtn');
    if (currentUser.role === 'analyst' && bulkUpdateBtn) {
        bulkUpdateBtn.style.display = 'inline-block';
    }
    loadTickets();
}

function preencherFiltroAnalista() {
    const select = document.getElementById('analystFilter');
    if (!select) return;
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const analysts = users.filter(u => u.role === 'analyst');
    select.innerHTML = '<option value="">Todos</option>' + analysts.map(a => `<option value="${a.id}">${a.name} (${a.email})</option>`).join('');
}

function setupTicketForm() {
    const selectedCategory = localStorage.getItem('selectedCategory');
    if (!selectedCategory) {
        window.location.href = 'index.html';
        return;
    }
    
    document.getElementById('selectedCategory').textContent = getCategoryDisplayName(selectedCategory);
    loadCategoryFields(selectedCategory);
}

function setupTicketDetail() {
    const urlParams = new URLSearchParams(window.location.search);
    const ticketId = urlParams.get('id');
    
    if (ticketId) {
        loadTicketDetail(ticketId);
    } else {
        window.location.href = 'dashboard.html';
    }
}

// Authentication functions
function handleLogin(e) {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const email = formData.get('email');
    const password = formData.get('password');
    const role = formData.get('role');
    
    // Simulate login (in real app, this would be an API call)
    const user = authenticateUser(email, password, role);
    
    if (user) {
        setCurrentUser(user);
        window.location.href = 'dashboard.html';
    } else {
        alert('Credenciais inválidas. Tente novamente.');
    }
}

function authenticateUser(email, password, role) {
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const user = users.find(u => u.email === email && u.password === password && u.role === role);
    if (user) {
        return { id: user.id, name: user.name, email: user.email, role: user.role };
    }
    return null;
}

function setCurrentUser(user) {
    localStorage.setItem('currentUser', JSON.stringify(user));
    currentUser = user;
}

function getCurrentUser() {
    const user = localStorage.getItem('currentUser');
    return user ? JSON.parse(user) : null;
}

function logout() {
    localStorage.removeItem('currentUser');
    localStorage.removeItem('selectedCategory');
    window.location.href = 'index.html';
}

// Ticket management functions
function handleTicketSubmission(e) {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const ticketData = {
        solicitationNumber: formData.get('solicitationNumber'),
        agency: formData.get('agency'),
        accountNumber: formData.get('accountNumber'),
        priority: formData.get('priority'),
        description: formData.get('description'),
        category: localStorage.getItem('selectedCategory'),
        categoryFields: getCategoryFieldsData(),
        attachments: formData.get('attachments'),
        createdBy: currentUser.id,
        createdAt: new Date().toISOString(),
        status: 'open'
    };
    
    // In real app, this would be an API call
    createTicket(ticketData);
    
    // Clear category selection
    localStorage.removeItem('selectedCategory');
    
    // Redirect to dashboard
    window.location.href = 'dashboard.html';
}

function createTicket(ticketData) {
    // Generate unique ID
    const ticketId = Date.now();
    const ticket = {
        id: ticketId,
        ...ticketData,
        interactions: [{
            type: 'created',
            user: currentUser.name,
            timestamp: new Date().toISOString(),
            comment: 'Ticket criado'
        }]
    };
    
    // Save to localStorage (in real app, this would be saved to database)
    const existingTickets = JSON.parse(localStorage.getItem('tickets') || '[]');
    existingTickets.push(ticket);
    localStorage.setItem('tickets', JSON.stringify(existingTickets));
    
    alert(`Ticket #${ticketId} criado com sucesso!`);
}

function loadTickets() {
    const allTickets = JSON.parse(localStorage.getItem('tickets') || '[]');
    
    // Filter tickets based on user role
    if (currentUser.role === 'requester') {
        tickets = allTickets.filter(ticket => ticket.createdBy === currentUser.id);
    } else if (currentUser.role === 'analyst') {
        tickets = allTickets.filter(ticket => ticket.assignedTo === currentUser.id || !ticket.assignedTo);
    } else {
        tickets = allTickets; // Admin sees all tickets
    }
    
    updateStats();
    renderTickets();
}

function updateStats() {
    const total = tickets.length;
    const open = tickets.filter(t => t.status === 'open').length;
    const progress = tickets.filter(t => t.status === 'progress').length;
    const resolved = tickets.filter(t => t.status === 'resolved').length;
    
    document.getElementById('totalTickets').textContent = total;
    document.getElementById('openTickets').textContent = open;
    document.getElementById('progressTickets').textContent = progress;
    document.getElementById('resolvedTickets').textContent = resolved;
}

function renderTickets() {
    const container = document.getElementById('ticketsContainer');
    if (!container) return;
    
    if (tickets.length === 0) {
        container.innerHTML = `
            <div class="text-center py-5">
                <i class="fas fa-inbox fa-3x text-muted mb-3"></i>
                <h4 class="text-muted">Nenhum ticket encontrado</h4>
                <p class="text-muted">Não há tickets para exibir no momento.</p>
            </div>
        `;
        return;
    }

    // Ordenar tickets do mais recente para o mais antigo
    const sortedTickets = [...tickets].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

    const ticketsHTML = sortedTickets.map(ticket => `
        <div class="dashboard-card">
            <div class="row align-items-center">
                <div class="col-md-1">
                    ${currentUser.role === 'analyst' ? `
                        <input type="checkbox" name="ticketSelect" value="${ticket.id}" class="form-check-input">
                    ` : ''}
                </div>
                <div class="col-md-2">
                    <strong>#${ticket.id}</strong>
                    <div class="text-muted small">${formatDate(ticket.createdAt)}</div>
                </div>
                <div class="col-md-3">
                    <div class="fw-bold">${ticket.solicitationNumber}</div>
                    <div class="text-muted small">${ticket.agency}</div>
                </div>
                <div class="col-md-2">
                    <span class="badge bg-primary">${getCategoryDisplayName(ticket.category)}</span>
                </div>
                <div class="col-md-2 text-end">
                    <button class="btn btn-sm btn-outline-primary" onclick="viewTicket(${ticket.id})">
                        <i class="fas fa-eye me-1"></i>Ver
                    </button>
                </div>
            </div>
        </div>
    `).join('');
    
    container.innerHTML = ticketsHTML;
}

function filterTickets() {
    loadTickets(); // Garante que tickets está atualizado
    const statusFilter = document.getElementById('statusFilter').value;
    const categoryFilter = document.getElementById('categoryFilter').value;
    const dateStart = document.getElementById('dateStartFilter').value;
    const dateEnd = document.getElementById('dateEndFilter').value;
    const analystFilter = document.getElementById('analystFilter');
    let filteredTickets = tickets;
    if (statusFilter) {
        filteredTickets = filteredTickets.filter(ticket => ticket.status === statusFilter);
    }
    if (categoryFilter) {
        filteredTickets = filteredTickets.filter(ticket => ticket.category === categoryFilter);
    }
    if (dateStart) {
        filteredTickets = filteredTickets.filter(ticket => new Date(ticket.createdAt) >= new Date(dateStart));
    }
    if (dateEnd) {
        filteredTickets = filteredTickets.filter(ticket => new Date(ticket.createdAt) <= new Date(dateEnd + 'T23:59:59'));
    }
    if (analystFilter && analystFilter.value) {
        filteredTickets = filteredTickets.filter(ticket => String(ticket.assignedTo) === analystFilter.value);
    }
    renderFilteredTickets(filteredTickets);
}

function renderFilteredTickets(filteredTickets) {
    const container = document.getElementById('ticketsContainer');
    if (!container) return;
    
    if (filteredTickets.length === 0) {
        container.innerHTML = `
            <div class="text-center py-5">
                <i class="fas fa-search fa-3x text-muted mb-3"></i>
                <h4 class="text-muted">Nenhum resultado encontrado</h4>
                <p class="text-muted">Tente ajustar os filtros.</p>
            </div>
        `;
        return;
    }

    // Ordenar tickets filtrados do mais recente para o mais antigo
    const sortedFiltered = [...filteredTickets].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

    const ticketsHTML = sortedFiltered.map(ticket => `
        <div class="dashboard-card">
            <div class="row align-items-center">
                <div class="col-md-1">
                    ${currentUser.role === 'analyst' ? `
                        <input type="checkbox" name="ticketSelect" value="${ticket.id}" class="form-check-input">
                    ` : ''}
                </div>
                <div class="col-md-2">
                    <strong>#${ticket.id}</strong>
                    <div class="text-muted small">${formatDate(ticket.createdAt)}</div>
                </div>
                <div class="col-md-3">
                    <div class="fw-bold">${ticket.solicitationNumber}</div>
                    <div class="text-muted small">${ticket.agency}</div>
                </div>
                <div class="col-md-2">
                    <span class="badge bg-primary">${getCategoryDisplayName(ticket.category)}</span>
                </div>
                <div class="col-md-2 text-end">
                    <button class="btn btn-sm btn-outline-primary" onclick="viewTicket(${ticket.id})">
                        <i class="fas fa-eye me-1"></i>Ver
                    </button>
                </div>
            </div>
        </div>
    `).join('');
    
    container.innerHTML = ticketsHTML;
}

// Category-specific functions
function loadCategoryFields(category) {
    const container = document.getElementById('categoryFields');
    if (!container) return;
    
    let fieldsHTML = '';
    
    switch (category) {
        case 'pade':
            fieldsHTML = `
                <div class="row mb-4">
                    <div class="col-md-6">
                        <label for="dataType" class="form-label">Tipo de Dados</label>
                        <select class="form-select" id="dataType" name="dataType" required>
                            <option value="">Selecione o tipo</option>
                            <option value="personal">Dados Pessoais</option>
                            <option value="financial">Dados Financeiros</option>
                            <option value="operational">Dados Operacionais</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label for="changeType" class="form-label">Tipo de Alteração</label>
                        <select class="form-select" id="changeType" name="changeType" required>
                            <option value="">Selecione o tipo</option>
                            <option value="insert">Inserção</option>
                            <option value="update">Atualização</option>
                            <option value="delete">Exclusão</option>
                        </select>
                    </div>
                </div>
            `;
            break;
            
        case 'meta':
            fieldsHTML = `
                <div class="row mb-4">
                    <div class="col-md-6">
                        <label for="metricType" class="form-label">Tipo de Métrica</label>
                        <select class="form-select" id="metricType" name="metricType" required>
                            <option value="">Selecione a métrica</option>
                            <option value="performance">Performance</option>
                            <option value="volume">Volume</option>
                            <option value="quality">Qualidade</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label for="timeframe" class="form-label">Período</label>
                        <select class="form-select" id="timeframe" name="timeframe" required>
                            <option value="">Selecione o período</option>
                            <option value="daily">Diário</option>
                            <option value="weekly">Semanal</option>
                            <option value="monthly">Mensal</option>
                        </select>
                    </div>
                </div>
            `;
            break;
            
        case 'encarteiramento':
            fieldsHTML = `
                <div class="row mb-4">
                    <div class="col-md-6">
                        <label for="exceptionType" class="form-label">Tipo de Exceção</label>
                        <select class="form-select" id="exceptionType" name="exceptionType" required>
                            <option value="">Selecione o tipo</option>
                            <option value="documentation">Documentação</option>
                            <option value="process">Processo</option>
                            <option value="system">Sistema</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label for="urgency" class="form-label">Urgência</label>
                        <select class="form-select" id="urgency" name="urgency" required>
                            <option value="">Selecione a urgência</option>
                            <option value="low">Baixa</option>
                            <option value="medium">Média</option>
                            <option value="high">Alta</option>
                            <option value="critical">Crítica</option>
                        </select>
                    </div>
                </div>
            `;
            break;
    }
    
    container.innerHTML = fieldsHTML;
}

function getCategoryFieldsData() {
    const category = localStorage.getItem('selectedCategory');
    const data = {};
    
    switch (category) {
        case 'pade':
            data.dataType = document.getElementById('dataType')?.value;
            data.changeType = document.getElementById('changeType')?.value;
            break;
        case 'meta':
            data.metricType = document.getElementById('metricType')?.value;
            data.timeframe = document.getElementById('timeframe')?.value;
            break;
        case 'encarteiramento':
            data.exceptionType = document.getElementById('exceptionType')?.value;
            data.urgency = document.getElementById('urgency')?.value;
            break;
    }
    
    return data;
}

// Ticket detail functions
function loadTicketDetail(ticketId) {
    const allTickets = JSON.parse(localStorage.getItem('tickets') || '[]');
    const ticket = allTickets.find(t => t.id == ticketId);
    
    if (!ticket) {
        alert('Ticket não encontrado');
        window.location.href = 'dashboard.html';
        return;
    }
    
    currentTicket = ticket;
    displayTicketDetails(ticket);
    renderTimeline(ticket);
    setupActionButtons(ticket);
}

function displayTicketDetails(ticket) {
    document.getElementById('ticketId').textContent = ticket.id;
    document.getElementById('ticketCreated').textContent = formatDate(ticket.createdAt);
    document.getElementById('ticketCreator').textContent = ticket.createdBy;
    document.getElementById('solicitationNumber').textContent = ticket.solicitationNumber;
    document.getElementById('agency').textContent = ticket.agency;
    document.getElementById('accountNumber').textContent = ticket.accountNumber;
    document.getElementById('category').textContent = getCategoryDisplayName(ticket.category);
    document.getElementById('description').textContent = ticket.description;
    
    // Update status and priority
    const statusElement = document.getElementById('ticketStatus');
    statusElement.className = `status-badge status-${ticket.status}`;
    statusElement.textContent = getStatusDisplayName(ticket.status);
    
    const priorityElement = document.getElementById('ticketPriority');
    priorityElement.textContent = getPriorityDisplayName(ticket.priority);
    priorityElement.className = `badge bg-${getPriorityColor(ticket.priority)}`;
    
    // Display category-specific fields
    displayCategoryFields(ticket);
}

function displayCategoryFields(ticket) {
    const container = document.getElementById('additionalFields');
    if (!container || !ticket.categoryFields) return;
    
    let fieldsHTML = '';
    
    switch (ticket.category) {
        case 'pade':
            fieldsHTML = `
                <div class="mb-3">
                    <strong>Tipo de Dados:</strong> ${getDataTypeDisplayName(ticket.categoryFields.dataType)}
                </div>
                <div class="mb-3">
                    <strong>Tipo de Alteração:</strong> ${getChangeTypeDisplayName(ticket.categoryFields.changeType)}
                </div>
            `;
            break;
        case 'meta':
            fieldsHTML = `
                <div class="mb-3">
                    <strong>Tipo de Métrica:</strong> ${getMetricTypeDisplayName(ticket.categoryFields.metricType)}
                </div>
                <div class="mb-3">
                    <strong>Período:</strong> ${getTimeframeDisplayName(ticket.categoryFields.timeframe)}
                </div>
            `;
            break;
        case 'encarteiramento':
            fieldsHTML = `
                <div class="mb-3">
                    <strong>Tipo de Exceção:</strong> ${getExceptionTypeDisplayName(ticket.categoryFields.exceptionType)}
                </div>
                <div class="mb-3">
                    <strong>Urgência:</strong> ${getUrgencyDisplayName(ticket.categoryFields.urgency)}
                </div>
            `;
            break;
    }
    
    container.innerHTML = fieldsHTML;
}

function renderTimeline(ticket) {
    const container = document.getElementById('timelineContainer');
    if (!container) return;
    
    const timelineHTML = ticket.interactions.map(interaction => `
        <div class="timeline-item">
            <div class="bg-white p-3 rounded shadow-soft">
                <div class="d-flex justify-content-between align-items-start mb-2">
                    <strong class="text-primary">${interaction.user}</strong>
                    <small class="text-muted">${formatDate(interaction.timestamp)}</small>
                </div>
                <div class="mb-2">
                    <span class="badge bg-secondary">${getInteractionTypeDisplayName(interaction.type)}</span>
                </div>
                ${interaction.comment ? `<p class="mb-0">${interaction.comment}</p>` : ''}
            </div>
        </div>
    `).join('');
    
    container.innerHTML = timelineHTML;
}

function setupActionButtons(ticket) {
    const assignBtn = document.getElementById('assignBtn');
    if (assignBtn && currentUser.role === 'admin') {
        assignBtn.style.display = 'inline-block';
    }
}

// Modal functions
function showUpdateModal() {
    const modal = new bootstrap.Modal(document.getElementById('updateStatusModal'));
    modal.show();
}

function showAssignModal() {
    // Preencher select de analistas
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const analysts = users.filter(u => u.role === 'analyst');
    const select = document.getElementById('assignedAnalyst');
    if (select) {
        select.innerHTML = '<option value="">Selecione um analista</option>' +
            analysts.map(a => `<option value="${a.id}">${a.name} (${a.email})</option>`).join('');
    }
    const modal = new bootstrap.Modal(document.getElementById('assignModal'));
    modal.show();
}

function showCommentModal() {
    const modal = new bootstrap.Modal(document.getElementById('commentModal'));
    modal.show();
}

function showBulkUpdateModal() {
    if (selectedTickets.length === 0) {
        alert('Selecione pelo menos um ticket para atualizar.');
        return;
    }
    const modal = new bootstrap.Modal(document.getElementById('bulkUpdateModal'));
    modal.show();
}

// Action functions
function updateTicketStatus() {
    const newStatus = document.getElementById('newStatus').value;
    const comment = document.getElementById('statusComment').value;
    
    if (!newStatus) {
        alert('Selecione um novo status.');
        return;
    }
    
    // Update ticket
    currentTicket.status = newStatus;
    currentTicket.interactions.push({
        type: 'status_change',
        user: currentUser.name,
        timestamp: new Date().toISOString(),
        comment: comment || `Status alterado para ${getStatusDisplayName(newStatus)}`
    });
    
    // Save to localStorage
    saveTicketUpdate(currentTicket);
    
    // Close modal and refresh
    bootstrap.Modal.getInstance(document.getElementById('updateStatusModal')).hide();
    displayTicketDetails(currentTicket);
    renderTimeline(currentTicket);
}

function assignTicket() {
    const analystId = document.getElementById('assignedAnalyst').value;
    const comment = document.getElementById('assignComment').value;
    
    if (!analystId) {
        alert('Selecione um analista.');
        return;
    }
    
    // Update ticket
    currentTicket.assignedTo = analystId;
    currentTicket.interactions.push({
        type: 'assigned',
        user: currentUser.name,
        timestamp: new Date().toISOString(),
        comment: comment || `Ticket atribuído ao analista`
    });
    
    // Save to localStorage
    saveTicketUpdate(currentTicket);
    
    // Close modal and refresh
    bootstrap.Modal.getInstance(document.getElementById('assignModal')).hide();
    displayTicketDetails(currentTicket);
    renderTimeline(currentTicket);
}

function addComment() {
    const comment = document.getElementById('newComment').value;
    
    if (!comment.trim()) {
        alert('Digite um comentário.');
        return;
    }
    
    // Add interaction
    currentTicket.interactions.push({
        type: 'comment',
        user: currentUser.name,
        timestamp: new Date().toISOString(),
        comment: comment
    });
    
    // Save to localStorage
    saveTicketUpdate(currentTicket);
    
    // Close modal and refresh
    bootstrap.Modal.getInstance(document.getElementById('commentModal')).hide();
    document.getElementById('newComment').value = '';
    renderTimeline(currentTicket);
}

function updateBulkStatus() {
    const newStatus = document.getElementById('bulkStatus').value;
    const comment = document.getElementById('bulkComment').value;
    if (!newStatus) {
        alert('Selecione um novo status.');
        return;
    }
    // Carregar todos os tickets uma vez
    const allTickets = JSON.parse(localStorage.getItem('tickets') || '[]');
    selectedTickets.forEach(ticketId => {
        const ticket = allTickets.find(t => t.id == ticketId);
        if (ticket) {
            ticket.status = newStatus;
            ticket.interactions.push({
                type: 'status_change',
                user: currentUser.name,
                timestamp: new Date().toISOString(),
                comment: comment || `Status alterado para ${getStatusDisplayName(newStatus)} (atualização em lote)`
            });
        }
    });
    // Salvar o array alterado
    localStorage.setItem('tickets', JSON.stringify(allTickets));
    // Fechar modal e atualizar tela
    bootstrap.Modal.getInstance(document.getElementById('bulkUpdateModal')).hide();
    selectedTickets = [];
    loadTickets();
}

function saveTicketUpdate(ticket) {
    const allTickets = JSON.parse(localStorage.getItem('tickets') || '[]');
    const index = allTickets.findIndex(t => t.id === ticket.id);
    
    if (index !== -1) {
        allTickets[index] = ticket;
        localStorage.setItem('tickets', JSON.stringify(allTickets));
    }
}

// Utility functions
function handleTicketSelection(checkbox) {
    if (checkbox.checked) {
        selectedTickets.push(checkbox.value);
    } else {
        selectedTickets = selectedTickets.filter(id => id !== checkbox.value);
    }
}

function viewTicket(ticketId) {
    window.location.href = `ticket-detail.html?id=${ticketId}`;
}

function createNewTicket() {
    window.location.href = 'index.html';
}

function refreshTickets() {
    loadTickets();
}

function loadInitialData() {
    // Load any initial data needed
}

// Display name functions
function getRoleDisplayName(role) {
    const roles = {
        'requester': 'Solicitante',
        'analyst': 'Analista',
        'admin': 'Administrador'
    };
    return roles[role] || role;
}

function getCategoryDisplayName(category) {
    const categories = {
        'pade': 'PADE',
        'meta': 'META',
        'encarteiramento': 'ENCARTEIRAMENTO POR EXCEÇÃO'
    };
    return categories[category] || category;
}

function getStatusDisplayName(status) {
    const statuses = {
        'open': 'Em Aberto',
        'progress': 'Em Progresso',
        'resolved': 'Resolvido'
    };
    return statuses[status] || status;
}

function getPriorityDisplayName(priority) {
    const priorities = {
        'low': 'Baixa',
        'medium': 'Média',
        'high': 'Alta',
        'urgent': 'Urgente'
    };
    return priorities[priority] || priority;
}

function getPriorityColor(priority) {
    const colors = {
        'low': 'success',
        'medium': 'warning',
        'high': 'danger',
        'urgent': 'danger'
    };
    return colors[priority] || 'secondary';
}

function getInteractionTypeDisplayName(type) {
    const types = {
        'created': 'Criado',
        'status_change': 'Mudança de Status',
        'assigned': 'Atribuído',
        'comment': 'Comentário'
    };
    return types[type] || type;
}

function getDataTypeDisplayName(type) {
    const types = {
        'personal': 'Dados Pessoais',
        'financial': 'Dados Financeiros',
        'operational': 'Dados Operacionais'
    };
    return types[type] || type;
}

function getChangeTypeDisplayName(type) {
    const types = {
        'insert': 'Inserção',
        'update': 'Atualização',
        'delete': 'Exclusão'
    };
    return types[type] || type;
}

function getMetricTypeDisplayName(type) {
    const types = {
        'performance': 'Performance',
        'volume': 'Volume',
        'quality': 'Qualidade'
    };
    return types[type] || type;
}

function getTimeframeDisplayName(type) {
    const types = {
        'daily': 'Diário',
        'weekly': 'Semanal',
        'monthly': 'Mensal'
    };
    return types[type] || type;
}

function getExceptionTypeDisplayName(type) {
    const types = {
        'documentation': 'Documentação',
        'process': 'Processo',
        'system': 'Sistema'
    };
    return types[type] || type;
}

function getUrgencyDisplayName(type) {
    const types = {
        'low': 'Baixa',
        'medium': 'Média',
        'high': 'Alta',
        'critical': 'Crítica'
    };
    return types[type] || type;
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

// Usuários de teste para facilitar login
function seedTestUsers() {
    if (!localStorage.getItem('testUsersSeeded')) {
        const users = [
            { id: 1, name: 'Solicitante', email: 'requester@test.com', password: '123456', role: 'requester' },
            { id: 2, name: 'Analista', email: 'analyst@test.com', password: '123456', role: 'analyst' },
            { id: 3, name: 'Administrador', email: 'admin@test.com', password: '123456', role: 'admin' },
            { id: 4, name: 'Ana Oliveira', email: 'analyst2@test.com', password: '1', role: 'analyst' }
        ];
        localStorage.setItem('users', JSON.stringify(users));
        localStorage.setItem('testUsersSeeded', '1');
    }
}

function requireAuth() {
    const user = getCurrentUser();
    if (!user) {
        window.location.href = 'login.html';
        return false;
    }
    document.body.classList.add('auth-ok');
    return true;
}

// Função para montar dinamicamente o menu superior em todas as páginas
function renderNavbar(activePage) {
    const user = getCurrentUser();
    const userName = user ? user.name : 'Usuário';
    const userRole = user ? user.role : '';
    const roleLabel = userRole ? ` <small>(${getRoleDisplayName(userRole)})</small>` : '';
    const nav = document.createElement('nav');
    nav.className = 'navbar navbar-expand-lg';
    nav.innerHTML = `
        <div class="container position-relative">
            <a class="navbar-brand d-flex align-items-center" href="index.html">
                <img src="img/logo.png" alt="Logo" width="36" height="36">
                Fale com a matriz!
            </a>
            <button class="navbar-toggler" type="button" aria-label="Menu" aria-expanded="false">
                <span class="fas fa-bars"></span>
            </button>
            <div class="navbar-nav ms-auto d-flex align-items-center">
                <a class="nav-link${activePage==='home' ? ' active' : ''}" href="index.html">Home</a>
                <a class="nav-link${activePage==='tickets' ? ' active' : ''}" href="dashboard.html#my-tickets">Meus chamados</a>
                <div class="dropdown ms-2">
                    <button class="btn btn-link navbar-user dropdown-toggle" type="button" id="userMenu" data-bs-toggle="dropdown" aria-expanded="false">
                        <span>${userName}${roleLabel}</span>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userMenu">
                        <li><a class="dropdown-item" href="#" onclick="logout()"><i class="fas fa-sign-out-alt me-2"></i>Log off</a></li>
                    </ul>
                </div>
            </div>
        </div>
    `;
    const body = document.body;
    body.insertBefore(nav, body.firstChild);

    // Responsividade: toggle menu
    const toggler = nav.querySelector('.navbar-toggler');
    const navLinks = nav.querySelector('.navbar-nav');
    if (toggler && navLinks) {
        toggler.addEventListener('click', function() {
            navLinks.classList.toggle('show');
            const expanded = navLinks.classList.contains('show');
            toggler.setAttribute('aria-expanded', expanded ? 'true' : 'false');
        });
    }
}
